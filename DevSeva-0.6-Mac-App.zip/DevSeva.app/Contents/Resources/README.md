# DevSeva / ದೇವಸೇವೆ — offline temple desk, version 0.6

DevSeva is an offline desktop app for temples, ashrams and religious event committees. It manages daily poojas, special sevas, festival bookings, devotee records, cashier collection and reports. It runs on one laptop with a local SQLite database. Phones can optionally enter bookings over a private Wi-Fi network served by that laptop. No internet, hosting account or cloud database is used during operation.

This is a working prototype (formerly "Seva Desk"). The DevSeva.app launcher uses the Python 3.10+ and Tk already installed on the Mac. **Build Standalone DevSeva.command** makes a version that doesn't need Python (see below).

## What's new in 0.6

**Staff logins with PINs.** The first time 0.6 opens, it asks you to create the Administrator login. After that, everyone logs in with their own name and a 4–12 digit PIN. Obvious PINs such as 1111 or 1234 are refused. PINs are stored only as salted PBKDF2 hashes, never in readable form. Five wrong PINs lock that login for 5 minutes, and an Admin can reset a PIN, which also unlocks the login.

The screen locks after 15 idle minutes, and the **Lock** button locks it immediately. Locking closes any open booking windows, so save first. Phone entry keeps running while the laptop is locked. **Change my PIN** is available to everyone. Every action is recorded under the person who did it, for example "Cashier: Lakshmi" or "Reception: Desk 1 (phone)".

What each role can do:

| Action | Reception | Cashier | Supervisor | Admin |
|---|---|---|---|---|
| Bookings, devotee register, printing | ✓ | ✓ | ✓ | ✓ |
| Receive payments, view reports and exports | | ✓ | ✓ | ✓ |
| Change fixed prices, cancel, refund, correct, link bookings, phone access, backups | | | ✓ | ✓ |
| Masters, staff logins, restore | | | | ✓ |

**Refunds (Supervisor or Admin).** Select a paid booking and choose **Refund…**, then enter the amount, the method and a reason (required).

- A **partial refund** keeps the sevas booked.
- A **full refund** marks the booking REFUNDED, removes its sevas from the priest sheet and frees their per-day slots.

Receipts list each refund and the net amount paid. Reports show refunds on the date they were given, by method, and a **net collection** figure. Refunds cannot exceed the amount paid.

**Corrections (Supervisor or Admin).** Every correction needs a reason and is written to the audit log with the old and new values.

- **Correct payment method…** fixes a payment recorded under the wrong method, for example Cash that was actually UPI.
- **Correct details / date…** fixes the devotee's name, Kannada name, phone, gotra, rashi, nakshatra or notes. It can also fix any slip's name and details, or move a daily-pooja booking to another allowed date. The per-day limit is checked when you move a booking.
- Amounts and sevas never change in place: refund and book again instead.
- Once **Confirm printed** has been used, any later print of that booking is marked **REPRINT / ನಕಲು ಪ್ರತಿ**.

**Gotra per family member.** Each member can have their own gotra, for example a married daughter. It prints on that person's slip and appears on the priest sheet. Searching for a gotra finds the family.

**Linking older bookings.** **Booking history** now lists older, unlinked bookings that match the family, either by a member's exact name or by phone number. Check each suggestion before you **Link** it. From the Bookings tab, **Link to devotee family…** links any booking and **Unlink family** undoes it.

**Encrypted phone connection (HTTPS).** **Mobile access** creates this laptop's own security certificate using the openssl tool built into macOS. The certificate is reused until the laptop's network address changes. Phones connect to `https://<laptop address>:8765`.

- **Certificate warning.** The first time, each phone warns that the connection is not private. Tap *Advanced / Show details → Proceed*.
- **Checking the laptop.** The laptop window shows the start of the certificate's SHA-256 fingerprint, so you can confirm the phone reached the right laptop.
- **Fallback.** If a certificate can't be made, DevSeva asks before starting without encryption. The phone page always shows whether the connection is encrypted.
- **Logging in.** The two shared access keys are gone. A phone now needs the **access code** shown on the laptop plus the staff member's **own name and PIN**. Each phone login lasts up to 12 hours or until you stop phone entry. Twenty wrong access codes block that phone until phone entry restarts.
- **Masked numbers.** Phones see register phone numbers masked (•••• 4567). Leave the phone field blank and the full number from the register is used.
- **Payments.** Only Cashier, Supervisor and Admin logins see the phone payment section.

**Restore inside the app (Admin).** **Restore backup** checks the file first: it must be undamaged and be a DevSeva or Seva Desk database. It then saves a safety copy of the current data in the `backups` folder, restores the backup and upgrades it if it's older. Everyone must log in again afterwards. If the backup is from before staff logins existed, you'll be asked to create an Admin.

**Automatic backups.** Each time you quit, a backup is saved to `backups` in the data folder. The last 10 are kept. Keep copying backups to a USB drive as well.

**Faster with many bookings.** The Bookings tab loads 300 bookings at a time, with **Show more** for older ones. Search runs inside the database and also matches the names on individual slips. The screen refreshes only when something has changed, for example a phone booking. DevSeva no longer leaves Python cache files inside the app.

**Self-test.** Running `DevSeva --selftest` (or `python3 app.py --selftest`) checks the database, PIN login, receipts, the phone page, certificate creation and Tk, without opening a window.

## Standalone app (no Python needed)

Keep **Build Standalone DevSeva.command** next to DevSeva.app and double-click it once, with internet on. It works as follows:

1. It downloads PyInstaller into a private build folder (`~/Library/Caches/DevSevaBuild`) and tests the source.
2. It builds DevSeva.app and tests the built app.
3. It signs the app and saves it with a ZIP in a new **DevSeva Standalone** folder.

Without an Apple Developer account the app has an ad-hoc signature, so macOS asks for *Open Anyway* once on each Mac. If you later get a Developer ID, set `DEVSEVA_SIGN_ID` and `DEVSEVA_NOTARY_PROFILE` (see the comments at the top of the script) and run it again to sign and notarise.

The build runs on the processor type of the Mac that built it, either Apple Silicon (arm64) or Intel (x86_64). Build on each type if you need both. It uses the same data folder as the launcher version.

## Version 0.5 features

**Rebrand.** The app is now called DevSeva. It still uses your existing database at `~/Library/Application Support/SevaDeskPrototype/seva-desk.sqlite3`, so every earlier booking stays in place. The folder name was deliberately left unchanged.

**Devotee register (Devotees tab).** Each family is saved with a phone number, gotra, address and notes. Each family member is saved with their English and Kannada name, relation, rashi and nakshatra. You can search by name, any member's name, gotra or phone digits. A possible duplicate phone number is flagged when you add a family. **Booking history** shows every booking linked to a family, and **New booking for family** opens a booking with the details filled in. Bookings made before 0.5 are not linked to any family automatically.

**A slip for each person.** In a booking, every seva line has a **Slip for** choice, either the main devotee or any family member. That person's name, Kannada name, rashi and nakshatra print on their own slip. **Add every member** adds one slip per active family member. The cashier summary shows who each line is for. Slips keep the details as they were when booked, so later register edits don't change printed history.

**Walk-in devotees.** Walk-ins can still be booked without the register. Tick **Save this new devotee to the register** to add them as a new family during the same save. A retry never creates the family twice.

**Daily poojas and special sevas.** In Masters, an event or calendar is one of two types. **Once** is a festival or event on one date; its bookings are for that date. **Daily** is a regular temple pooja calendar with a start date, an optional end date and the days it runs (for example "All" or "Mon, Fri"); bookings choose a pooja date within those rules. Any seva can have a **per-day limit** (0 means no limit). The limit is checked safely even when several phones book at once, and cancelled bookings free their slot. Remaining slots are shown while booking.

**Postponed festivals.** If you change a Once event's date, its active bookings move to the new date and the change is written to the audit log. Receipts show the new pooja date, while the stored event snapshot keeps the original details.

**Archive.** Events and sevas can be archived. They disappear from new bookings on the laptop and phones but stay in history and reports. **Restore** brings them back.

**Pooja schedule tab.** The priest's day sheet lists every non-cancelled slip for a date, grouped by seva, with name, Kannada name, gotra, rashi, nakshatra and payment state. You can move day by day and filter by event. **Print priest sheet** opens a printable A4 page.

**Reports tab.** Choose a date range (with Today, This week, This month and This year shortcuts) and an optional event filter. The report shows:

- cash collected by the date payment was received, split by payment method, by seva and by day;
- bookings entered in the period, cancellations and in-kind slips;
- the unpaid balance;
- sevas scheduled in the period by pooja date.

**Print report** opens a printable page. **Export slip-level CSV** writes one row per slip. AED and INR are never converted or added together.

**Bookings tab.** You can search by name, booking number or phone digits, and double-click a booking to preview it. The list now shows the pooja date and slip count, and the footer shows today's collections and the unpaid balance for all dates.

**Phones.** The phone page offers the same devotee search, per-member slips, "every member" button, pooja date picker, remaining slots, gotra and save-to-register option. Archived events are hidden. When a booking is rejected (for example because a seva is full), the phone says nothing was saved and lets you correct the booking. Only connection or server failures keep the "Retry same booking" lock, so a booking is never duplicated.

## Daily use

0. **Log in** with your name and PIN. The first time, create the Admin login, then add volunteers under **Staff logins**.
1. **Masters:** add your festival (Type: Once) or temple calendar (Type: Daily), then its sevas, sponsorships and in-kind categories.
2. **Devotees:** add regular devotee families and their members.
3. **New booking:** choose the event, then the pooja date if it's a Daily calendar. Use **Find…** to pick a family, or type a walk-in devotee. Add seva lines, choosing who each slip is for, then **Save and preview slips** and print from the browser. Click **Confirm printed** only after the paper has actually printed.
4. **Cashier:** select the booking, then **Receive payment**. Payment is never recorded automatically when slips print.
5. **Pooja schedule:** print the priest sheet for the day.
6. **Reports:** review collections at the end of the day, then use **Backup database**.

Unpaid bookings can be cancelled with a reason. A Supervisor or Admin handles paid bookings with **Refund…** and the **Correct…** buttons, which are described above.

## Phones and hotspot

Keep the laptop and phones on the same private, password-protected Wi-Fi or hotspot.

1. Add each volunteer under **Staff logins**.
2. A Supervisor or Admin clicks **Mobile access**.
3. On each phone, open the `https://…:8765` address shown, accept the one-time certificate warning, and log in with the access code, your name and your PIN.

Phones can search the devotee register, which shows names and gotra, with phone numbers masked. Stop mobile access when finished: every phone is logged out, and the access code changes next time. Never use public Wi-Fi or set up port forwarding. Allow incoming connections if the macOS firewall asks.

## Data and backup

The database is `SevaDeskPrototype/seva-desk.sqlite3` in `~/Library/Application Support` (Windows: Local AppData). Use **Backup database** after each session and copy the file to a secure external drive. The backup includes the devotee register, glossary and audit log.

To restore:

1. Quit all copies of the app.
2. Keep a copy of the whole data folder.
3. Move the database and its `-wal`/`-shm` files aside.
4. Copy the backup into the folder, named `seva-desk.sqlite3`.
5. Open the app and check the register.

Version 0.5 upgrades the database automatically and additively: it adds new tables and columns, and existing bookings keep their amounts, status and receipt details. Once upgraded, the database should be opened only with 0.5 or later. The old 0.4 app will not show the new information and has not been tested against an upgraded database.

Automatic backups are saved in the `backups` folder inside the data folder, and **Restore backup** does the restore steps above for you. The database and backups themselves are not encrypted, so protect the Mac with its own login password and FileVault. The phone connection's certificate is stored in the `tls` folder. Receipt, schedule and report previews are temporary files that are deleted when the app closes normally.

## Kannada

Event and seva names use an offline glossary that translates by meaning, and corrections you save are remembered. Devotee names get an editable phonetic suggestion. Always have the Kannada spelling checked with the devotee, and have a fluent reader review public wording.

## Verification

Run `python3 -m unittest test_core test_kannada test_v05 test_v06` from the Resources folder. The 41 tests cover:

- **Earlier behaviour:** receipts, retries and parallel entry, prices, payments, cancellations, in-kind entries, backups, the Kannada glossary, daily-pooja rules, per-day limits, per-person slips, the register, schedules and reports.
- **Staff logins:** PIN hashing and lockout, role permissions and the last-Admin rule.
- **Refunds and corrections:** partial and full refunds (including freed slots and net reports), payment-method and detail corrections with rescheduling, and reprint marking.
- **Register and bookings:** per-member gotra, link suggestions, paged search and change detection.
- **Backups:** refusing bad files, restoring (including a real v0.4 backup that still has its unsaved `-wal` journal file) and pruning automatic backups.
- **Phone connection:** HTTPS login, masked numbers, role limits, logout and blocking of wrong access codes.

In a Linux test environment, the whole desktop flow was also run end to end, the phone page was tested in Chromium over HTTPS, and the standalone build was checked with its self-test. Native macOS behaviour, iPhone/Android certificate prompts, Kannada rendering, physical printers and the Mac standalone build still need testing on your devices.

## Still to do before commercial release

- **Printing:** automatic thermal printing with a tested printer.
- **Data encryption:** an encrypted database file.
- **Distribution:** Windows installer, notarisation (needs an Apple Developer account) and offline licensing.
- **Phone setup:** QR-code pairing, so staff don't type the address and access code.
