"""DevSeva desktop app. Run with Python 3.10+ on macOS or Windows: python3 app.py"""
import datetime as dt
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import uuid
import webbrowser
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
from core import (Store, receipt, schedule_html, report_html, report_text, money, fmt, weekday_text,
                  APP_NAME, APP_NAME_KN, VERSION, CURRENCIES, KINDS, METHODS, RECURRENCES, RELATIONS)
from mobile import start
import security
from kannada import bind_suggestion, translate_label, suggest, RASHIS, NAKSHATRAS

MAX_ROWS = 1000
PAGE_SIZE = 300
IDLE_LOCK_MINUTES = 15
AUTO_BACKUPS_KEPT = 10


def data_folder():
    # Kept from Seva Desk so upgrades keep using the existing database.
    if sys.platform == 'win32':
        base = Path(os.environ.get('LOCALAPPDATA', str(Path.home())))
    elif sys.platform == 'darwin':
        base = Path.home() / 'Library' / 'Application Support'
    else:
        base = Path.home() / '.local' / 'share'
    folder = base / 'SevaDeskPrototype'
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def today():
    return dt.date.today().isoformat()


class App:
    def __init__(self, root, folder=None):
        self.root = root
        self.folder = Path(folder) if folder else data_folder()
        self.db_path = self.folder / 'seva-desk.sqlite3'
        self.store = Store(self.db_path)
        self.server = None
        self.server_info = None
        self.previews = []
        self.user = None
        self.last_activity = time.monotonic()
        self.version_seen = None
        self.page_limit = PAGE_SIZE
        root.title(f'{APP_NAME} / {APP_NAME_KN} — offline temple desk {VERSION}')
        root.geometry('1240x820')
        root.minsize(980, 660)
        ttk.Style().configure('TButton', padding=6)
        self.body = ttk.Frame(root)
        head = ttk.Frame(self.body)
        head.pack(fill='x', padx=18, pady=(14, 2))
        ttk.Label(head, text=f'{APP_NAME} / {APP_NAME_KN}', font=('', 22, 'bold')).pack(side='left')
        ttk.Label(head, text='   Daily poojas • Festival sevas • Devotee register • Offline').pack(side='left')
        ttk.Button(head, text='Lock / ಲಾಕ್', command=self.lock).pack(side='right', padx=3)
        ttk.Button(head, text='Change my PIN', command=lambda: self.safe(self.change_my_pin)).pack(side='right', padx=3)
        self.who = ttk.Label(head, text='', font=('', 12, 'bold'))
        self.who.pack(side='right', padx=10)
        bar = ttk.Frame(self.body)
        bar.pack(fill='x', padx=15, pady=8)
        for title, command in [('New booking / ನೋಂದಣಿ', self.booking), ('Mobile access', self.mobile),
                               ('Backup database', self.backup), ('Restore backup', self.restore),
                               ('Export register CSV', self.export), ('Staff logins', self.staff)]:
            ttk.Button(bar, text=title, command=lambda c=command: self.safe(c)).pack(side='left', padx=3)
        self.width = tk.StringVar(value='80')
        ttk.Label(bar, text='Slip paper mm:').pack(side='left', padx=8)
        ttk.Combobox(bar, textvariable=self.width, values=['58', '80'], width=4, state='readonly').pack(side='left')
        self.mobile_state = ttk.Label(bar, text='')
        self.mobile_state.pack(side='left', padx=10)
        self.tabs = ttk.Notebook(self.body)
        self.tabs.pack(fill='both', expand=True, padx=15, pady=5)
        self.build_bookings()
        self.build_schedule()
        self.build_devotees()
        self.build_reports()
        self.build_masters()
        self.status = ttk.Label(self.body, text=f'Screen locks after {IDLE_LOCK_MINUTES} idle minutes. '
                                'Receipts open in your browser for printing. A backup is saved automatically when you quit.')
        self.status.pack(anchor='w', padx=15, pady=6)
        self.gate = ttk.Frame(root, padding=40)
        root.protocol('WM_DELETE_WINDOW', self.close)
        for sequence in ('<Any-KeyPress>', '<Any-ButtonPress>', '<Motion>'):
            root.bind_all(sequence, self.touch, add='+')
        self.show_gate()
        self.poll()

    # ------------------------------------------------------- login and locking
    @property
    def actor(self):
        return f"{self.user['role']}: {self.user['name']}" if self.user else 'Nobody'

    def need(self, action):
        if not self.user:
            raise PermissionError('Log in first.')
        security.require(self.user['role'], action)

    def allowed(self, action):
        return bool(self.user) and security.can(self.user['role'], action)

    def touch(self, _event=None):
        self.last_activity = time.monotonic()

    def close_windows(self):
        for w in self.root.winfo_children():
            if isinstance(w, tk.Toplevel):
                w.destroy()

    def lock(self):
        self.close_windows()
        self.user = None
        self.show_gate()

    def show_gate(self):
        self.body.pack_forget()
        for w in self.gate.winfo_children():
            w.destroy()
        self.gate.pack(fill='both', expand=True)
        box = ttk.Frame(self.gate)
        box.place(relx=0.5, rely=0.42, anchor='center')
        ttk.Label(box, text=f'{APP_NAME} / {APP_NAME_KN}', font=('', 28, 'bold')).grid(row=0, column=0, columnspan=2, pady=(0, 4))
        first = not self.store.has_staff()
        name, pin, pin2 = tk.StringVar(), tk.StringVar(), tk.StringVar()
        message = ttk.Label(box, text='', foreground='#b00020', wraplength=420)
        if first:
            ttk.Label(box, text='Welcome. Create the Administrator login for this laptop.\n'
                      'Use a PIN of 4–12 digits that others cannot guess. Keep it safe: '
                      'only an Admin can add staff or reset PINs.', wraplength=420, justify='center').grid(row=1, column=0, columnspan=2, pady=12)
            ttk.Label(box, text='Admin name').grid(row=2, column=0, sticky='w', pady=5)
            entry = ttk.Entry(box, textvariable=name, width=28)
            entry.grid(row=2, column=1, pady=5)
            ttk.Label(box, text='PIN').grid(row=3, column=0, sticky='w', pady=5)
            ttk.Entry(box, textvariable=pin, show='•', width=28).grid(row=3, column=1, pady=5)
            ttk.Label(box, text='Repeat PIN').grid(row=4, column=0, sticky='w', pady=5)
            last = ttk.Entry(box, textvariable=pin2, show='•', width=28)
            last.grid(row=4, column=1, pady=5)
            def go(*_):
                try:
                    if pin.get() != pin2.get():
                        raise ValueError('The two PINs do not match.')
                    self.store.add_staff(name.get(), 'Admin', pin.get(), 'First-time setup')
                    self.unlock(self.store.login(name.get(), pin.get()))
                except Exception as ex:
                    message.config(text=str(ex))
            button = ttk.Button(box, text='Create Admin and start', command=go)
        else:
            ttk.Label(box, text='Log in with your name and PIN / ಹೆಸರು ಮತ್ತು ಪಿನ್', wraplength=420).grid(row=1, column=0, columnspan=2, pady=12)
            names = [x['name'] for x in self.store.staff_list(active_only=True)]
            ttk.Label(box, text='Name').grid(row=2, column=0, sticky='w', pady=5)
            entry = ttk.Combobox(box, textvariable=name, values=names, width=26)
            entry.grid(row=2, column=1, pady=5)
            if len(names) == 1:
                name.set(names[0])
            ttk.Label(box, text='PIN').grid(row=3, column=0, sticky='w', pady=5)
            last = ttk.Entry(box, textvariable=pin, show='•', width=28)
            last.grid(row=3, column=1, pady=5)
            def go(*_):
                try:
                    self.unlock(self.store.login(name.get(), pin.get()))
                except Exception as ex:
                    pin.set('')
                    message.config(text=str(ex))
            button = ttk.Button(box, text='Log in', command=go)
            if self.server:
                ttk.Label(box, text='Mobile access is still running for phones.', foreground='#555').grid(row=7, column=0, columnspan=2, pady=4)
        button.grid(row=5, column=1, sticky='e', pady=12)
        message.grid(row=6, column=0, columnspan=2)
        last.bind('<Return>', go)
        (last if name.get() else entry).focus_set()
        self.login_widgets = {'name': name, 'pin': pin, 'pin2': pin2, 'go': go, 'message': message}

    def unlock(self, user):
        self.user = user
        self.touch()
        self.gate.pack_forget()
        self.body.pack(fill='both', expand=True)
        self.who.config(text=f"{user['name']} · {user['role']}")
        self.page_limit = PAGE_SIZE
        self.version_seen = None
        self.refresh()
        self.refresh_devotees()

    def change_my_pin(self):
        current = simpledialog.askstring('Change my PIN', 'Current PIN:', show='•', parent=self.root)
        if current is None:
            return
        self.store.login(self.user['name'], current)
        new = simpledialog.askstring('Change my PIN', 'New PIN (4–12 digits):', show='•', parent=self.root)
        if new is None:
            return
        if new != simpledialog.askstring('Change my PIN', 'Repeat new PIN:', show='•', parent=self.root):
            raise ValueError('The two PINs do not match. Nothing changed.')
        self.store.set_pin(self.user['id'], new, self.actor)
        messagebox.showinfo(APP_NAME, 'Your PIN has been changed.', parent=self.root)

    # ----------------------------------------------------------------- helpers
    def safe(self, command, parent=None):
        try:
            return command()
        except Exception as ex:
            messagebox.showerror(APP_NAME, str(ex), parent=parent or self.root)

    def button_row(self, parent, buttons):
        row = ttk.Frame(parent)
        row.pack(fill='x', pady=6)
        for title, command in buttons:
            ttk.Button(row, text=title, command=lambda c=command: self.safe(c)).pack(side='left', padx=3)
        return row

    def table(self, parent, columns, labels, height=12, widths=None, expand=True):
        frame = ttk.Frame(parent)
        frame.pack(fill='both', expand=expand, pady=4)
        tree = ttk.Treeview(frame, columns=columns, show='headings', height=height, selectmode='browse')
        for i, (column, label) in enumerate(zip(columns, labels)):
            tree.heading(column, text=label)
            tree.column(column, width=(widths or {}).get(column, 120), minwidth=40, stretch=True)
        scroll = ttk.Scrollbar(frame, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        tree.pack(fill='both', expand=True)
        return tree

    def selected(self, tree=None, what='row'):
        chosen = (tree or self.tree).selection()
        if not chosen:
            raise ValueError(f'Select a {what} first.')
        return int(chosen[0])

    @staticmethod
    def fill(tree, rows):
        keep = tree.selection()
        tree.delete(*tree.get_children())
        for iid, values in rows:
            tree.insert('', 'end', iid=str(iid), values=values)
        if keep and tree.exists(keep[0]):
            tree.selection_set(keep[0])

    def open_html(self, content, prefix='devseva-'):
        handle, path = tempfile.mkstemp(prefix=prefix, suffix='.html')
        with os.fdopen(handle, 'w', encoding='utf-8') as f:
            f.write(content)
        self.previews.append(path)
        webbrowser.open(Path(path).as_uri())

    def event_choices(self, active_only=True, include_all=False):
        events = self.store.catalog(active_only)['events']
        options = {'All events': None} if include_all else {}
        options.update({f"{e['id']} · {e['name']} ({e['currency']})": e['id'] for e in events})
        return options

    def form(self, title, fields, on_save, kannada=None, parent=None):
        """fields: (key, label, value, choices). kannada: (source, target, 'label' | 'name')."""
        win = tk.Toplevel(parent or self.root)
        win.title(title)
        win.transient(parent or self.root)
        frame = ttk.Frame(win, padding=18)
        frame.pack(fill='both', expand=True)
        values = {}
        for i, (key, label, value, choices) in enumerate(fields):
            ttk.Label(frame, text=label).grid(row=i, column=0, sticky='w', padx=4, pady=6)
            var = tk.StringVar(value=str(value))
            values[key] = var
            if choices:
                widget = ttk.Combobox(frame, textvariable=var, values=choices, state='readonly', width=40)
            else:
                widget = ttk.Entry(frame, textvariable=var, width=43)
            widget.grid(row=i, column=1, sticky='ew', padx=4, pady=6)
        n = len(fields)
        if kannada:
            source, target, mode = kannada
            if mode == 'label':
                saved = self.store.label_dictionary()
                convert = lambda text: translate_label(text, saved)
            else:
                convert = suggest
            reset = bind_suggestion(values[source], values[target], convert)
            ttk.Button(frame, text='Use Kannada glossary' if mode == 'label' else 'Regenerate Kannada',
                       command=reset).grid(row=n + 1, column=1, sticky='e')
            hint = ttk.Label(frame, text='', wraplength=460)
            hint.grid(row=n + 2, column=0, columnspan=2, pady=8)
            def explain(*_):
                if mode != 'label':
                    hint.config(text='Phonetic suggestion only. Check the Kannada spelling with the devotee.')
                elif convert(values[source].get()):
                    hint.config(text='Offline glossary available. Review the Kannada wording. Corrections are remembered when saved.')
                else:
                    hint.config(text='No glossary match. Enter the Kannada wording once; it will be remembered.')
            values[source].trace_add('write', explain)
            explain()
        def save():
            try:
                on_save({k: v.get() for k, v in values.items()})
                win.destroy()
                self.refresh()
                self.refresh_devotees()
            except Exception as ex:
                messagebox.showerror(title, str(ex), parent=win)
        ttk.Button(frame, text='Save / ಉಳಿಸಿ', command=save).grid(row=n, column=1, sticky='e', pady=12)
        return win

    # ---------------------------------------------------------------- bookings
    def build_bookings(self):
        tab = ttk.Frame(self.tabs, padding=6)
        self.tabs.add(tab, text='Bookings & cashier / ನೋಂದಣಿ')
        top = ttk.Frame(tab)
        top.pack(fill='x')
        ttk.Label(top, text='Search name, slip name, booking no. or phone:').pack(side='left')
        self.booking_filter = tk.StringVar()
        ttk.Entry(top, textvariable=self.booking_filter, width=30).pack(side='left', padx=6)
        self.booking_filter.trace_add('write', lambda *_: self.safe(self.search_bookings))
        self.more_button = ttk.Button(top, text='Show more', command=lambda: self.safe(self.more_bookings))
        self.more_button.pack(side='right')
        self.tree = self.table(tab, ('id', 'date', 'event', 'devotee', 'slips', 'currency', 'amount', 'status', 'print'),
                               ('Booking', 'Pooja date', 'Event', 'Devotee', 'Slips', 'Cur.', 'Total', 'Payment', 'Print queue'),
                               widths={'id': 70, 'slips': 50, 'currency': 50, 'date': 95, 'event': 220, 'devotee': 220})
        self.tree.bind('<Double-1>', lambda _: self.safe(self.preview))
        self.button_row(tab, [('Preview / print slips', self.preview), ('Confirm printed', self.printed),
                              ('Receive payment', self.pay), ('Cancel unpaid booking', self.void), ('Refresh', self.refresh)])
        self.button_row(tab, [('Refund…', self.refund), ('Correct details / date…', self.correct_details),
                              ('Correct payment method…', self.correct_payment),
                              ('Link to devotee family…', self.link_booking), ('Unlink family', self.unlink_booking)])
        self.summary = ttk.Label(tab, text='')
        self.summary.pack(anchor='w', pady=6)

    def search_bookings(self):
        self.page_limit = PAGE_SIZE
        self.refresh_bookings()

    def more_bookings(self):
        self.page_limit += PAGE_SIZE
        self.refresh_bookings()

    def refresh_bookings(self):
        rows, more = self.store.bookings_page(self.booking_filter.get(), self.page_limit)
        values = []
        for b in rows:
            e = json.loads(b['snapshot'])
            status = b['status'] + (f" (−{fmt(b['refunded'])})" if b['status'] == 'PAID' and b['refunded'] else '')
            values.append((b['id'], (b['id'], b['service_date'], e['name'], b['devotee'], b['slips'], e['currency'],
                                     fmt(b['total']), status, 'Pending' if b['print_pending'] else 'Confirmed')))
        self.fill(self.tree, values)
        if more:
            self.more_button.state(['!disabled'])
        else:
            self.more_button.state(['disabled'])
        parts = []
        if self.allowed('reports'):
            rep = self.store.report(today(), today())
            net = ' · '.join(f'{c} {fmt(v)}' for c, v in sorted(rep['net'].items())) or 'nothing yet'
            unpaid = ' · '.join(f'{c} {fmt(v)}' for c, v in sorted(self.store.unpaid_total().items()) if v) or 'none'
            parts += [f'Net collected today: {net}', f'Unpaid (all dates): {unpaid}']
        parts.append(f'Showing {len(rows)} booking(s)' + (' — click Show more for older ones' if more else ''))
        self.summary.config(text='     |     '.join(parts))

    def selected_booking(self):
        return self.store.detail(self.selected(what='booking'))

    def preview(self):
        self.open_html(receipt(self.selected_booking(), int(self.width.get())), 'devseva-receipt-')

    def printed(self):
        self.need('print')
        bid = self.selected(what='booking')
        if messagebox.askyesno('Confirm printing', 'Have all seva slips and the cashier summary physically printed?\n'
                               'Any later print of this booking will be marked REPRINT.'):
            self.store.printed(bid, self.actor)
            self.refresh()

    def pay(self):
        self.need('pay')
        b = self.selected_booking()
        if b['status'] != 'UNPAID':
            raise ValueError('Select an unpaid booking.')
        if b['total'] <= 0:
            raise ValueError('No cash is due on this booking.')
        def save(v):
            if not messagebox.askyesno('Confirm payment', f"Have you received {b['event']['currency']} {fmt(b['total'])} from {b['devotee']}?"):
                raise ValueError('Payment not recorded.')
            self.store.pay(b['id'], self.actor, v['method'])
        self.form('Receive payment', [('method', 'Payment method', 'Cash', list(METHODS))], save)

    def void(self):
        self.need('void')
        bid = self.selected(what='booking')
        reason = simpledialog.askstring('Cancel unpaid booking', 'Reason (record stays in the audit log):', parent=self.root)
        if reason:
            self.store.void(bid, reason, self.actor)
            self.refresh()

    def refund(self):
        self.need('refund')
        b = self.selected_booking()
        if b['status'] != 'PAID':
            raise ValueError('Select a paid booking. Unpaid bookings are cancelled instead of refunded.')
        left = b['total'] - b['refunded']
        cur = b['event']['currency']
        def save(v):
            amount = money(v['amount'])
            kind = 'FULL refund — the sevas will be removed from the schedule' if amount == left else 'PARTIAL refund — the sevas stay booked'
            if not messagebox.askyesno('Confirm refund', f"Give back {cur} {fmt(amount)} to {b['devotee']} by {v['method']}?\n\n{kind}."):
                raise ValueError('Refund not recorded.')
            self.store.refund(b['id'], self.actor, v['amount'], v['method'], v['reason'])
        self.form(f"Refund booking #{b['id']:06d}",
                  [('amount', f'Amount to refund ({cur}, up to {fmt(left)})', f'{left / 100:.2f}', None),
                   ('method', 'Refund paid by', b['payment_method'] or 'Cash', list(METHODS)),
                   ('reason', 'Reason (required)', '', None)], save)

    def correct_payment(self):
        self.need('correct')
        b = self.selected_booking()
        if b['status'] not in ('PAID', 'REFUNDED'):
            raise ValueError('Select a paid booking.')
        self.form(f"Correct payment method #{b['id']:06d}",
                  [('method', f"Actual method (recorded: {b['payment_method']})", b['payment_method'], list(METHODS)),
                   ('reason', 'Reason (required)', '', None)],
                  lambda v: self.store.correct_payment(b['id'], v['method'], v['reason'], self.actor))

    def correct_details(self):
        self.need('correct')
        b = self.selected_booking()
        if b['status'] in ('VOID', 'REFUNDED'):
            raise ValueError('Cancelled or fully refunded bookings cannot be corrected.')
        win = tk.Toplevel(self.root)
        win.title(f"Correct booking #{b['id']:06d}")
        win.transient(self.root)
        outer = ttk.Frame(win, padding=14)
        outer.pack(fill='both', expand=True)
        ttk.Label(outer, text='Fix spelling or astrology details, or move a daily pooja to another date. '
                  'Amounts and sevas cannot change here — refund and book again instead. Every change is audited.',
                  wraplength=720).grid(row=0, column=0, columnspan=6, sticky='w', pady=(0, 8))
        v = {k: tk.StringVar(value=str(b.get(k) or '')) for k in ('devotee', 'devotee_kn', 'phone', 'gotra', 'rashi', 'nakshatra', 'note', 'service_date')}
        fields = [('devotee', 'Devotee name', None), ('devotee_kn', 'Kannada name', None), ('phone', 'Phone', None),
                  ('gotra', 'Gotra', None), ('rashi', 'Rashi', [''] + RASHIS), ('nakshatra', 'Nakshatra', [''] + NAKSHATRAS),
                  ('note', 'Notes', None)]
        daily = b['event'].get('recurrence') == 'Daily'
        if daily:
            fields.append(('service_date', 'Pooja date YYYY-MM-DD', None))
        r = 1
        for key, label, choices in fields:
            ttk.Label(outer, text=label).grid(row=r, column=0, sticky='w', pady=3)
            widget = ttk.Combobox(outer, textvariable=v[key], values=choices, state='readonly', width=40) if choices \
                else ttk.Entry(outer, textvariable=v[key], width=43)
            widget.grid(row=r, column=1, columnspan=3, sticky='w', pady=3)
            r += 1
        ttk.Label(outer, text='Slips', font=('', 12, 'bold')).grid(row=r, column=0, sticky='w', pady=(10, 2))
        r += 1
        for c, label in enumerate(('Seva', 'Name on slip', 'Kannada', 'Rashi', 'Nakshatra', 'Gotra')):
            ttk.Label(outer, text=label).grid(row=r, column=c, sticky='w')
        r += 1
        slips = {}
        for item in b['items']:
            ttk.Label(outer, text=f"#{item['id']} {item['name']}").grid(row=r, column=0, sticky='w')
            sv = {k: tk.StringVar(value=item.get(k) or '') for k in ('person', 'person_kn', 'rashi', 'nakshatra', 'gotra')}
            ttk.Entry(outer, textvariable=sv['person'], width=18).grid(row=r, column=1, padx=2, pady=2)
            ttk.Entry(outer, textvariable=sv['person_kn'], width=16).grid(row=r, column=2, padx=2)
            ttk.Combobox(outer, textvariable=sv['rashi'], values=[''] + RASHIS, state='readonly', width=16).grid(row=r, column=3, padx=2)
            ttk.Combobox(outer, textvariable=sv['nakshatra'], values=[''] + NAKSHATRAS, state='readonly', width=20).grid(row=r, column=4, padx=2)
            ttk.Entry(outer, textvariable=sv['gotra'], width=12).grid(row=r, column=5, padx=2)
            slips[item['id']] = sv
            r += 1
        reason = tk.StringVar()
        ttk.Label(outer, text='Reason (required)').grid(row=r, column=0, sticky='w', pady=(10, 0))
        ttk.Entry(outer, textvariable=reason, width=60).grid(row=r, column=1, columnspan=4, sticky='w', pady=(10, 0))
        def save():
            values = {k: var.get() for k, var in v.items() if k != 'service_date' or daily}
            values['items'] = {iid: {k: var.get() for k, var in sv.items()} for iid, sv in slips.items()}
            self.store.correct_details(b['id'], values, reason.get(), self.actor)
            win.destroy()
            self.refresh()
            messagebox.showinfo('Correction saved', 'Saved. Print the booking again if the paper slips need replacing; they will show REPRINT.', parent=self.root)
        ttk.Button(outer, text='Save correction', command=lambda: self.safe(save, win)).grid(row=r + 1, column=4, columnspan=2, sticky='e', pady=12)
        return win

    def link_booking(self):
        self.need('link')
        bid = self.selected(what='booking')
        def chosen(fid):
            self.store.link_booking(bid, fid, self.actor)
            self.refresh()
            self.refresh_devotees()
            messagebox.showinfo(APP_NAME, f'Booking #{bid:06d} is now in that family\'s history.', parent=self.root)
        self.pick_family(self.root, lambda fid: self.safe(lambda: chosen(fid)))

    def unlink_booking(self):
        self.need('link')
        bid = self.selected(what='booking')
        if messagebox.askyesno('Unlink', 'Remove this booking from its devotee family history? The booking itself is not changed.'):
            self.store.unlink_booking(bid, self.actor)
            self.refresh()
            self.refresh_devotees()

    # ------------------------------------------------------------ new booking
    def booking(self, family_id=None):
        self.need('book')
        override = self.allowed('override_price')
        cat = self.store.catalog(active_only=True)
        if not cat['sevas']:
            raise ValueError('Create an event or daily pooja calendar and its sevas in Masters first.')
        events = {e['id']: e for e in cat['events']}
        labels = {f"{e['id']} · {e['name']} ({e['currency']})": e['id'] for e in cat['events']
                  if any(s['event_id'] == e['id'] for s in cat['sevas'])}
        win = tk.Toplevel(self.root)
        win.title('New booking / ಸೇವಾ ನೋಂದಣಿ')
        win.geometry('820x860')
        frame = ttk.Frame(win, padding=14)
        frame.pack(fill='both', expand=True)
        frame.columnconfigure(1, weight=1)
        v = {k: tk.StringVar() for k in ('event', 'date', 'family', 'devotee', 'devotee_kn', 'phone', 'gotra',
                                          'rashi', 'nakshatra', 'note', 'seva', 'person', 'qty', 'amount')}
        save_new = tk.BooleanVar(value=False)
        state = {'family_id': None, 'members': {}, 'lines': []}
        r = 0
        def row(label, widget, extra=None):
            nonlocal r
            ttk.Label(frame, text=label).grid(row=r, column=0, sticky='w', pady=4)
            widget.grid(row=r, column=1, sticky='ew', pady=4)
            if extra:
                extra.grid(row=r, column=2, sticky='w', padx=6)
            r += 1
            return widget
        row('Event / pooja calendar', ttk.Combobox(frame, textvariable=v['event'], values=list(labels), state='readonly'))
        date_entry = row('Pooja date YYYY-MM-DD', ttk.Entry(frame, textvariable=v['date']))
        date_hint = ttk.Label(frame, text='', foreground='#555')
        date_hint.grid(row=r, column=1, sticky='w')
        r += 1
        fam_buttons = ttk.Frame(frame)
        row('Devotee register', ttk.Entry(frame, textvariable=v['family'], state='readonly'), fam_buttons)
        row('Devotee name (English)', ttk.Entry(frame, textvariable=v['devotee']))
        row('Kannada name (editable)', ttk.Entry(frame, textvariable=v['devotee_kn']))
        row('Phone (optional)', ttk.Entry(frame, textvariable=v['phone']))
        row('Gotra / ಗೋತ್ರ (optional)', ttk.Entry(frame, textvariable=v['gotra']))
        row('Rashi / ರಾಶಿ', ttk.Combobox(frame, textvariable=v['rashi'], values=[''] + RASHIS, state='readonly'))
        row('Nakshatra / ನಕ್ಷತ್ರ', ttk.Combobox(frame, textvariable=v['nakshatra'], values=[''] + NAKSHATRAS, state='readonly'))
        row('Notes / in-kind details', ttk.Entry(frame, textvariable=v['note']))
        save_check = ttk.Checkbutton(frame, text='Save this new devotee to the register', variable=save_new)
        save_check.grid(row=r, column=1, sticky='w')
        reset_kn = bind_suggestion(v['devotee'], v['devotee_kn'])
        ttk.Button(frame, text='Regenerate Kannada', command=reset_kn).grid(row=r, column=2, sticky='w', padx=6)
        r += 1
        ttk.Separator(frame).grid(row=r, column=0, columnspan=3, sticky='ew', pady=10)
        r += 1
        seva_combo = row('Seva', ttk.Combobox(frame, textvariable=v['seva'], state='readonly'))
        avail = ttk.Label(frame, text='', foreground='#555')
        avail.grid(row=r, column=1, sticky='w')
        r += 1
        person_combo = row('Slip for (family member)', ttk.Combobox(frame, textvariable=v['person'], state='readonly'))
        row('Quantity (one slip each)', ttk.Entry(frame, textvariable=v['qty']))
        amount_entry = row('Amount each' + (' (you may change it)' if override else ' (fixed; sponsorships editable)'),
                           ttk.Entry(frame, textvariable=v['amount']))
        choices = {}
        MAIN = 'Main devotee (details above)'

        def current_event():
            return events[labels[v['event'].get()]]

        def set_family(fid):
            fam = self.store.family_detail(fid)
            active = [m for m in fam['members'] if m['active']]
            state['family_id'] = fid
            state['members'] = {f"{m['name']} ({m['relation']})": m for m in active}
            main = next((m for m in active if m['relation'] == 'Self'), active[0] if active else None)
            v['family'].set(f"#{fid} · {fam['head']} · {len(active)} member(s)")
            v['devotee'].set(main['name'] if main else fam['head'])
            v['devotee_kn'].set(main['kannada'] if main else '')
            v['rashi'].set(main['rashi'] if main else '')
            v['nakshatra'].set(main['nakshatra'] if main else '')
            v['phone'].set(fam['phone'])
            v['gotra'].set((main['gotra'] if main else '') or fam['gotra'])
            save_new.set(False)
            save_check.state(['disabled'])
            person_combo.config(values=[MAIN] + list(state['members']))
            v['person'].set(MAIN)
            if state['lines'] and any(l.get('member_id') for l in state['lines']):
                clear()

        def clear_family():
            state['family_id'] = None
            state['members'] = {}
            v['family'].set('Not selected — walk-in devotee')
            save_check.state(['!disabled'])
            person_combo.config(values=[MAIN])
            v['person'].set(MAIN)
            if any(l.get('member_id') for l in state['lines']):
                clear()

        ttk.Button(fam_buttons, text='Find…', command=lambda: self.safe(lambda: self.pick_family(win, set_family), win)).pack(side='left')
        ttk.Button(fam_buttons, text='Clear', command=clear_family).pack(side='left')

        def update_availability(*_):
            s = choices.get(v['seva'].get())
            if not s or not s['daily_limit']:
                avail.config(text='')
                return
            try:
                left = self.store.availability(s['event_id'], v['date'].get())[s['id']]
                pending = sum(l['quantity'] for l in state['lines'] if l['seva_id'] == s['id'])
                avail.config(text=f"{left - pending} of {s['daily_limit']} slots free on {v['date'].get()}")
            except (ValueError, KeyError):
                avail.config(text=f"Limit {s['daily_limit']} per day — enter a valid pooja date")

        def price(*_):
            s = choices.get(v['seva'].get())
            if s:
                v['amount'].set(f"{s['price'] / 100:.2f}")
                editable = override or s['kind'] == 'Sponsorship'
                amount_entry.state(['!disabled'] if editable else ['disabled'])
            update_availability()

        def event_changed(*_):
            clear()
            e = current_event()
            choices.clear()
            choices.update({f"{s['name']} / {s['kannada']}  ·  {s['kind']}": s for s in cat['sevas'] if s['event_id'] == e['id']})
            seva_combo.config(values=list(choices))
            v['seva'].set(next(iter(choices), ''))
            if e['recurrence'] == 'Daily':
                date_entry.state(['!disabled'])
                if not v['date'].get() or v['date'].get() < e['day']:
                    v['date'].set(max(today(), e['day']))
                end = f" until {e['end_day']}" if e['end_day'] else ''
                date_hint.config(text=f"Daily pooja · days: {weekday_text(e['weekdays'])} · from {e['day']}{end}")
            else:
                v['date'].set(e['day'])
                date_entry.state(['disabled'])
                date_hint.config(text=f"Festival / event on {e['day']} at {e['place']}")
            price()

        cart = tk.Listbox(frame, height=7)
        total = ttk.Label(frame, text='', font=('', 13, 'bold'))

        def redraw():
            cart.delete(0, 'end')
            for l in state['lines']:
                cart.insert('end', f"{l['quantity']} × {l['label']}  —  for {l['who']}  =  {fmt(money(l['amount']) * l['quantity'])}")
            amount = sum(money(l['amount']) * l['quantity'] for l in state['lines'])
            total.config(text=f"Total: {current_event()['currency']} {fmt(amount)}" if state['lines'] else '')
            update_availability()

        def add():
            s = choices.get(v['seva'].get())
            if not s:
                raise ValueError('Choose a seva.')
            text = v['qty'].get().strip()
            if not text.isdigit():
                raise ValueError('Quantity must be a whole number.')
            q, p = int(text), money(v['amount'].get())
            if q < 1 or sum(l['quantity'] for l in state['lines']) + q > 100:
                raise ValueError('Use 1–100 total slips.')
            if s['kind'] == 'In-kind' and p:
                raise ValueError('In-kind contributions must have zero cash amount.')
            member = state['members'].get(v['person'].get())
            state['lines'].append({'seva_id': s['id'], 'quantity': q, 'amount': f'{p / 100:.2f}',
                                   'member_id': member['id'] if member else None, 'label': s['name'],
                                   'who': member['name'] if member else (v['devotee'].get() or 'main devotee')})
            v['qty'].set('1')
            redraw()

        def remove():
            chosen = cart.curselection()
            if not chosen:
                raise ValueError('Select a line in the list to remove.')
            del state['lines'][chosen[0]]
            redraw()

        def clear():
            state['lines'].clear()
            redraw()

        buttons = ttk.Frame(frame)
        buttons.grid(row=r, column=1, sticky='e')
        ttk.Button(buttons, text='Add seva line', command=lambda: self.safe(add, win)).pack(side='left', padx=3)
        ttk.Button(buttons, text='Add every member', command=lambda: self.safe(add_all, win)).pack(side='left', padx=3)
        r += 1
        cart.grid(row=r, column=0, columnspan=3, sticky='ew', pady=6)
        r += 1
        total.grid(row=r, column=0, columnspan=2, sticky='w')
        r += 1

        def add_all():
            if not state['members']:
                raise ValueError('Select a devotee family from the register first.')
            before = v['person'].get()
            for label in list(state['members']):
                v['person'].set(label)
                add()
            v['person'].set(before)

        key = str(uuid.uuid4())

        def save():
            if not state['lines']:
                raise ValueError('Add at least one seva line.')
            data = {k: v[k].get() for k in ('devotee', 'devotee_kn', 'phone', 'gotra', 'rashi', 'nakshatra', 'note')}
            data.update(request_key=key, event_id=current_event()['id'], service_date=v['date'].get(),
                        family_id=state['family_id'], save_devotee=bool(save_new.get()) and not state['family_id'],
                        items=[{k: l[k] for k in ('seva_id', 'quantity', 'amount', 'member_id')} for l in state['lines']])
            bid = self.store.book(data, self.actor, override)
            win.destroy()
            self.booking_filter.set('')
            self.refresh()
            self.refresh_devotees()
            self.tabs.select(0)
            self.tree.selection_set(str(bid))
            self.tree.see(str(bid))
            self.preview()

        actions = ttk.Frame(frame)
        actions.grid(row=r, column=0, columnspan=3, sticky='ew', pady=10)
        ttk.Button(actions, text='Remove selected line', command=lambda: self.safe(remove, win)).pack(side='left', padx=3)
        ttk.Button(actions, text='Clear lines', command=clear).pack(side='left', padx=3)
        ttk.Button(actions, text='Save and preview slips', command=lambda: self.safe(save, win)).pack(side='right', padx=3)

        v['qty'].set('1')
        v['event'].trace_add('write', event_changed)
        v['date'].trace_add('write', update_availability)
        seva_combo.bind('<<ComboboxSelected>>', price)
        v['event'].set(next(iter(labels)))
        if family_id:
            set_family(family_id)
        else:
            clear_family()
        return win

    def pick_family(self, parent, on_pick):
        win = tk.Toplevel(parent)
        win.title('Find devotee / ಭಕ್ತರ ಹುಡುಕಾಟ')
        win.geometry('720x460')
        win.transient(parent)
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill='both', expand=True)
        query = tk.StringVar()
        top = ttk.Frame(frame)
        top.pack(fill='x')
        ttk.Label(top, text='Name, family member, gotra or phone digits:').pack(side='left')
        entry = ttk.Entry(top, textvariable=query, width=30)
        entry.pack(side='left', padx=6)
        entry.focus_set()
        tree = self.table(frame, ('id', 'head', 'phone', 'gotra', 'members'), ('ID', 'Family', 'Phone', 'Gotra', 'Members'),
                          widths={'id': 50, 'members': 260})
        def search(*_):
            self.fill(tree, [(f['id'], (f['id'], f['head'], f['phone'], f['gotra'],
                                        ', '.join(m['name'] for m in f['members'] if m['active'])))
                             for f in self.store.families(query.get(), 200)])
        def choose(*_):
            fid = self.selected(tree, 'devotee family')
            win.destroy()
            on_pick(fid)
        query.trace_add('write', search)
        tree.bind('<Double-1>', lambda _: self.safe(choose, win))
        ttk.Button(frame, text='Use selected devotee', command=lambda: self.safe(choose, win)).pack(anchor='e')
        search()

    # ---------------------------------------------------------------- schedule
    def build_schedule(self):
        tab = ttk.Frame(self.tabs, padding=6)
        self.tabs.add(tab, text='Pooja schedule / ಪೂಜಾ ಪಟ್ಟಿ')
        top = ttk.Frame(tab)
        top.pack(fill='x')
        self.sched_date = tk.StringVar(value=today())
        self.sched_event = tk.StringVar(value='All events')
        ttk.Label(top, text='Date:').pack(side='left')
        ttk.Button(top, text='◀', width=3, command=lambda: self.safe(lambda: self.shift_day(-1))).pack(side='left')
        ttk.Entry(top, textvariable=self.sched_date, width=12).pack(side='left', padx=3)
        ttk.Button(top, text='▶', width=3, command=lambda: self.safe(lambda: self.shift_day(1))).pack(side='left')
        ttk.Button(top, text='Today', command=lambda: self.sched_date.set(today())).pack(side='left', padx=4)
        ttk.Label(top, text='   Event:').pack(side='left')
        self.sched_combo = ttk.Combobox(top, textvariable=self.sched_event, state='readonly', width=36)
        self.sched_combo.pack(side='left', padx=4)
        ttk.Button(top, text='Print priest sheet', command=lambda: self.safe(self.print_schedule)).pack(side='left', padx=8)
        self.sched_count = ttk.Label(tab, text='')
        self.sched_count.pack(anchor='w', pady=4)
        self.sched_tree = self.table(tab, ('seva', 'person', 'kn', 'gotra', 'rashi', 'nakshatra', 'booking', 'payment'),
                                     ('Seva', 'Name', 'Kannada', 'Gotra', 'Rashi', 'Nakshatra', 'Booking', 'Payment'),
                                     widths={'booking': 70, 'payment': 70})
        self.sched_date.trace_add('write', lambda *_: self.safe_schedule())
        self.sched_event.trace_add('write', lambda *_: self.safe_schedule())

    def shift_day(self, days):
        day = dt.date.fromisoformat(self.sched_date.get().strip()) + dt.timedelta(days=days)
        self.sched_date.set(day.isoformat())

    def schedule_rows(self):
        options = self.event_choices(active_only=False, include_all=True)
        return self.store.schedule(self.sched_date.get(), options.get(self.sched_event.get()))

    def safe_schedule(self):
        try:
            rows = self.schedule_rows()
        except ValueError:
            self.sched_count.config(text='Enter a date as YYYY-MM-DD.')
            self.fill(self.sched_tree, [])
            return
        self.fill(self.sched_tree, [(r['id'], (r['name'], r['person'], r['person_kn'], r['gotra'], r['rashi'], r['nakshatra'],
                                               r['booking'], 'Paid' if r['status'] == 'PAID' else ('In-kind' if r['kind'] == 'In-kind' else 'Due')))
                                    for r in rows])
        counts = {}
        for r in rows:
            counts[r['name']] = counts.get(r['name'], 0) + 1
        day = dt.date.fromisoformat(self.sched_date.get().strip())
        self.sched_count.config(text=f"{day:%A %d %B %Y}: {len(rows)} sevas   " + '  ·  '.join(f'{k}: {n}' for k, n in sorted(counts.items())))

    def print_schedule(self):
        self.open_html(schedule_html(self.sched_date.get().strip(), self.schedule_rows()), 'devseva-schedule-')

    # ---------------------------------------------------------------- devotees
    def build_devotees(self):
        tab = ttk.Frame(self.tabs, padding=6)
        self.tabs.add(tab, text='Devotees / ಭಕ್ತರು')
        top = ttk.Frame(tab)
        top.pack(fill='x')
        ttk.Label(top, text='Search name, member, gotra or phone:').pack(side='left')
        self.dev_query = tk.StringVar()
        ttk.Entry(top, textvariable=self.dev_query, width=30).pack(side='left', padx=6)
        self.dev_query.trace_add('write', lambda *_: self.safe(self.refresh_devotees))
        self.dev_count = ttk.Label(top, text='')
        self.dev_count.pack(side='left', padx=10)
        self.fam_tree = self.table(tab, ('id', 'head', 'phone', 'gotra', 'members', 'bookings'),
                                   ('ID', 'Family / devotee', 'Phone', 'Gotra', 'Members', 'Bookings'), height=9,
                                   widths={'id': 50, 'members': 70, 'bookings': 70, 'head': 260})
        self.fam_tree.bind('<<TreeviewSelect>>', lambda _: self.safe(self.refresh_members))
        self.button_row(tab, [('Add family / devotee', self.edit_family),
                              ('Edit family', lambda: self.edit_family(self.selected(self.fam_tree, 'family'))),
                              ('New booking for family', lambda: self.booking(self.selected(self.fam_tree, 'family'))),
                              ('Booking history', self.family_history)])
        ttk.Label(tab, text='Family members — each can have their own seva slip with their rashi and nakshatra').pack(anchor='w')
        self.mem_tree = self.table(tab, ('id', 'name', 'kn', 'relation', 'gotra', 'rashi', 'nakshatra', 'active'),
                                   ('ID', 'Name', 'Kannada', 'Relation', 'Gotra', 'Rashi', 'Nakshatra', 'Active'), height=6,
                                   widths={'id': 50, 'active': 60})
        self.button_row(tab, [('Add member', self.edit_member),
                              ('Edit member', lambda: self.edit_member(self.selected(self.mem_tree, 'member')))])

    def refresh_devotees(self):
        families = self.store.families(self.dev_query.get(), MAX_ROWS)
        with self.store.connect() as db:
            counts = dict(db.execute('SELECT family_id, COUNT(*) FROM bookings WHERE family_id IS NOT NULL GROUP BY family_id').fetchall())
        self.fill(self.fam_tree, [(f['id'], (f['id'], f['head'], f['phone'], f['gotra'],
                                             sum(1 for m in f['members'] if m['active']), counts.get(f['id'], 0)))
                                  for f in families])
        self.dev_count.config(text=f'{len(families)} families shown')
        self.refresh_members()

    def refresh_members(self):
        chosen = self.fam_tree.selection()
        members = self.store.family_detail(int(chosen[0]))['members'] if chosen else []
        self.fill(self.mem_tree, [(m['id'], (m['id'], m['name'], m['kannada'], m['relation'], m['gotra'], m['rashi'], m['nakshatra'],
                                             'Yes' if m['active'] else 'No')) for m in members])

    def edit_family(self, ident=None):
        self.need('devotees')
        f = self.store.family_detail(ident) if ident else {}
        fields = [('head', 'Family / main devotee name', f.get('head', ''), None),
                  ('phone', 'Phone', f.get('phone', ''), None),
                  ('gotra', 'Gotra / ಗೋತ್ರ', f.get('gotra', ''), None),
                  ('address', 'Address / place', f.get('address', ''), None),
                  ('notes', 'Notes', f.get('notes', ''), None)]
        def save(values):
            phone = ''.join(c for c in values['phone'] if c.isdigit())
            if not ident and len(phone) >= 6:
                same = [x for x in self.store.families(phone) if x['id'] != ident]
                if same and not messagebox.askyesno('Possible duplicate', f"Family #{same[0]['id']} ({same[0]['head']}) has this phone number. Create a new family anyway?"):
                    raise ValueError('Not saved. Use the existing family instead.')
            fid = self.store.family(values, ident, self.actor)
            if not ident:
                self.store.member(dict(family_id=fid, name=values['head'], kannada=suggest(values['head']), relation='Self',
                                       gotra=values['gotra']), actor=self.actor)
                self.dev_query.set('')
                self.refresh_devotees()
                self.fam_tree.selection_set(str(fid))
                self.fam_tree.see(str(fid))
                messagebox.showinfo('Devotee saved', 'Family saved with the main devotee as a member. '
                                    'Use Edit member to check the Kannada name and add rashi/nakshatra.')
        self.form('Devotee family', fields, save)

    def edit_member(self, ident=None):
        self.need('devotees')
        fid = self.selected(self.fam_tree, 'family')
        family = self.store.family_detail(fid)
        m = next((x for x in family['members'] if x['id'] == ident), {})
        fields = [('name', 'Name (English)', m.get('name', ''), None),
                  ('kannada', 'Kannada name', m.get('kannada', ''), None),
                  ('relation', 'Relation', m.get('relation', 'Spouse' if not ident else 'Self'), list(RELATIONS)),
                  ('gotra', 'Gotra / ಗೋತ್ರ (if different from family)', m.get('gotra', family['gotra']), None),
                  ('rashi', 'Rashi / ರಾಶಿ', m.get('rashi', ''), [''] + RASHIS),
                  ('nakshatra', 'Nakshatra / ನಕ್ಷತ್ರ', m.get('nakshatra', ''), [''] + NAKSHATRAS),
                  ('active', 'Active', 'Yes' if m.get('active', 1) else 'No', ['Yes', 'No'])]
        def save(values):
            values['family_id'] = fid
            self.store.member(values, ident, self.actor)
        self.form('Family member', fields, save, kannada=('name', 'kannada', 'name'))

    def family_history(self):
        fid = self.selected(self.fam_tree, 'family')
        f = self.store.family_detail(fid)
        win = tk.Toplevel(self.root)
        win.title(f"Booking history — {f['head']}")
        win.geometry('880x600')
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill='both', expand=True)
        columns = ('id', 'date', 'event', 'devotee', 'total', 'status')
        labels = ('Booking', 'Pooja date', 'Event', 'Devotee', 'Total', 'Payment')
        def rows(bookings, extra=None):
            out = []
            for b in bookings:
                e = json.loads(b['snapshot'])
                values = (b['id'], b['service_date'], e['name'], b['devotee'], f"{e['currency']} {fmt(b['total'])}", b['status'])
                out.append((b['id'], values + ((b['match'],) if extra else ())))
            return out
        ttk.Label(frame, text='Linked bookings', font=('', 12, 'bold')).pack(anchor='w')
        tree = self.table(frame, columns, labels, height=8)
        suggestions = self.store.link_suggestions(fid)
        ttk.Label(frame, text=f'Older unlinked bookings that look like this family ({len(suggestions)})',
                  font=('', 12, 'bold')).pack(anchor='w', pady=(10, 0))
        sug = self.table(frame, columns + ('match',), labels + ('Matched on',), height=6)
        def load():
            fresh = self.store.family_detail(fid)
            self.fill(tree, rows(fresh['bookings']))
            self.fill(sug, rows(self.store.link_suggestions(fid), True))
        def open_receipt(source):
            self.open_html(receipt(self.store.detail(self.selected(source, 'booking')), int(self.width.get())), 'devseva-receipt-')
        def link():
            self.need('link')
            self.store.link_booking(self.selected(sug, 'suggested booking'), fid, self.actor)
            load()
            self.refresh_devotees()
        def unlink():
            self.need('link')
            self.store.unlink_booking(self.selected(tree, 'linked booking'), self.actor)
            load()
            self.refresh_devotees()
        buttons = ttk.Frame(frame)
        buttons.pack(fill='x', pady=8)
        for title, command in (('Preview linked receipt', lambda: open_receipt(tree)), ('Unlink selected', unlink),
                               ('Preview suggested receipt', lambda: open_receipt(sug)), ('Link suggested booking', link)):
            ttk.Button(buttons, text=title, command=lambda c=command: self.safe(c, win)).pack(side='left', padx=3)
        ttk.Label(frame, text='Suggestions match the devotee name to any family member, or the phone number. '
                  'Check each one before linking.', foreground='#555').pack(anchor='w')
        load()
        return win

    # ----------------------------------------------------------------- reports
    def build_reports(self):
        tab = ttk.Frame(self.tabs, padding=6)
        self.tabs.add(tab, text='Reports / ವರದಿ')
        top = ttk.Frame(tab)
        top.pack(fill='x')
        self.rep_from = tk.StringVar(value=today())
        self.rep_to = tk.StringVar(value=today())
        self.rep_event = tk.StringVar(value='All events')
        for label, var in (('From', self.rep_from), ('To', self.rep_to)):
            ttk.Label(top, text=label).pack(side='left', padx=(6, 2))
            ttk.Entry(top, textvariable=var, width=12).pack(side='left')
        ttk.Label(top, text='  Event').pack(side='left')
        self.rep_combo = ttk.Combobox(top, textvariable=self.rep_event, state='readonly', width=34)
        self.rep_combo.pack(side='left', padx=4)
        quick = ttk.Frame(tab)
        quick.pack(fill='x', pady=6)
        def period(kind):
            d = dt.date.today()
            start = {'today': d, 'week': d - dt.timedelta(days=d.weekday()), 'month': d.replace(day=1), 'year': d.replace(month=1, day=1)}[kind]
            self.rep_from.set(start.isoformat())
            self.rep_to.set(d.isoformat())
            self.show_report()
        for title, kind in (('Today', 'today'), ('This week', 'week'), ('This month', 'month'), ('This year', 'year')):
            ttk.Button(quick, text=title, command=lambda k=kind: self.safe(lambda: period(k))).pack(side='left', padx=3)
        for title, command in (('Show report', self.show_report), ('Print report', self.print_report),
                               ('Export slip-level CSV', self.export_report)):
            ttk.Button(quick, text=title, command=lambda c=command: self.safe(c)).pack(side='left', padx=3)
        self.rep_text = tk.Text(tab, wrap='none', font=('Menlo' if sys.platform == 'darwin' else 'Courier', 12))
        self.rep_text.pack(fill='both', expand=True)

    def current_report(self):
        self.need('reports')
        event_id = self.event_choices(active_only=False, include_all=True).get(self.rep_event.get())
        return self.store.report(self.rep_from.get(), self.rep_to.get(), event_id), event_id

    def show_report(self):
        rep, _ = self.current_report()
        self.rep_text.config(state='normal')
        self.rep_text.delete('1.0', 'end')
        self.rep_text.insert('end', f'Event filter: {self.rep_event.get()}\n' + report_text(rep))
        self.rep_text.config(state='disabled')

    def print_report(self):
        rep, _ = self.current_report()
        self.open_html(report_html(rep, f'Collection report — {self.rep_event.get()}'), 'devseva-report-')

    def export_report(self):
        rep, event_id = self.current_report()
        dest = filedialog.asksaveasfilename(defaultextension='.csv', initialfile=f"devseva-slips-{rep['start']}-to-{rep['end']}.csv")
        if dest:
            self.store.export_lines(dest, rep['start'], rep['end'], event_id)
            messagebox.showinfo('Export', 'Slip-level report saved. A slip is included if it was booked, paid or scheduled in the period.')

    # ----------------------------------------------------------------- masters
    def build_masters(self):
        tab = ttk.Frame(self.tabs, padding=6)
        self.tabs.add(tab, text='Masters / ವಿವರಗಳು')
        ttk.Label(tab, text='Events and pooja calendars — "Once" for a festival or event day, "Daily" for regular temple poojas').pack(anchor='w')
        self.events = self.table(tab, ('id', 'name', 'type', 'day', 'end', 'days', 'place', 'currency', 'status'),
                                 ('ID', 'Name', 'Type', 'Date / start', 'End', 'Days', 'Place', 'Cur.', 'Status'), height=6,
                                 widths={'id': 40, 'type': 60, 'currency': 50, 'status': 70, 'name': 240})
        self.button_row(tab, [('Add event / calendar', self.edit_event),
                              ('Edit selected', lambda: self.edit_event(self.selected(self.events, 'event'))),
                              ('Archive / restore', lambda: self.toggle('events', self.events))])
        ttk.Label(tab, text='Sevas, sponsorships and in-kind categories').pack(anchor='w', pady=(8, 0))
        self.sevas = self.table(tab, ('id', 'event', 'name', 'kn', 'kind', 'price', 'limit', 'status'),
                                ('ID', 'Event', 'Seva', 'Kannada', 'Type', 'Default amount', 'Per-day limit', 'Status'), height=8,
                                widths={'id': 40, 'status': 70, 'limit': 90})
        self.button_row(tab, [('Add seva / sponsorship', self.edit_seva),
                              ('Edit selected seva', lambda: self.edit_seva(self.selected(self.sevas, 'seva'))),
                              ('Archive / restore', lambda: self.toggle('sevas', self.sevas))])
        ttk.Label(tab, text='Archived items stay in history and reports but are hidden from new bookings. Existing receipts keep their original details and rates.').pack(anchor='w')

    def refresh_masters(self):
        cat = self.store.catalog()
        names = {e['id']: e['name'] for e in cat['events']}
        self.fill(self.events, [(e['id'], (e['id'], e['name'], e['recurrence'], e['day'], e['end_day'] or '—',
                                           weekday_text(e['weekdays']) if e['recurrence'] == 'Daily' else '—', e['place'],
                                           e['currency'], 'Active' if e['active'] else 'Archived')) for e in cat['events']])
        self.fill(self.sevas, [(s['id'], (s['id'], names.get(s['event_id'], s['event_id']), s['name'], s['kannada'], s['kind'],
                                          fmt(s['price']), s['daily_limit'] or 'No limit', 'Active' if s['active'] else 'Archived'))
                               for s in cat['sevas']])
        choices = list(self.event_choices(active_only=False, include_all=True))
        for combo, var in ((self.sched_combo, self.sched_event), (self.rep_combo, self.rep_event)):
            combo.config(values=choices)
            if var.get() not in choices:
                var.set('All events')

    def toggle(self, table, tree):
        self.need('masters')
        ident = self.selected(tree)
        active = tree.set(str(ident), 'status') == 'Active'
        self.store.set_active(table, ident, not active, self.actor)
        self.refresh()

    def edit_event(self, ident=None):
        self.need('masters')
        e = next((x for x in self.store.catalog()['events'] if x['id'] == ident), {})
        fields = [('name', 'Event / calendar name', e.get('name', ''), None),
                  ('kannada', 'Kannada name / ಕನ್ನಡ ಹೆಸರು', e.get('kannada', ''), None),
                  ('recurrence', 'Type', e.get('recurrence', 'Once'), list(RECURRENCES)),
                  ('day', 'Date (Once) or start date (Daily) YYYY-MM-DD', e.get('day', today()), None),
                  ('end_day', 'End date (Daily only, optional)', e.get('end_day', ''), None),
                  ('weekdays', 'Days (Daily only): All or e.g. Mon, Fri', weekday_text(e.get('weekdays')), None),
                  ('place', 'Place / ಸ್ಥಳ', e.get('place', ''), None),
                  ('currency', 'Currency', e.get('currency', 'AED'), list(CURRENCIES))]
        self.form('Event / pooja calendar', fields, lambda v: self.store.event(v, ident, self.actor), kannada=('name', 'kannada', 'label'))

    def edit_seva(self, ident=None):
        self.need('masters')
        cat = self.store.catalog()
        if not cat['events']:
            raise ValueError('Create an event or daily pooja calendar first.')
        options = {f"{e['id']} · {e['name']}": e['id'] for e in cat['events']}
        s = next((x for x in cat['sevas'] if x['id'] == ident), {})
        selected = next((k for k, val in options.items() if val == s.get('event_id')), next(iter(options)))
        fields = [('event_id', 'Event / calendar', selected, list(options)),
                  ('name', 'Seva / contribution name', s.get('name', ''), None),
                  ('kannada', 'Kannada name', s.get('kannada', ''), None),
                  ('kind', 'Type', s.get('kind', 'Seva'), list(KINDS)),
                  ('price', 'Default cash amount', f"{s.get('price', 0) / 100:.2f}", None),
                  ('daily_limit', 'Per-day limit (0 = no limit)', s.get('daily_limit', 0), None)]
        def save(v):
            v['event_id'] = options[v['event_id']]
            self.store.seva(v, ident, self.actor)
        self.form('Seva master', fields, save, kannada=('name', 'kannada', 'label'))

    # ------------------------------------------------------------------ global
    def refresh(self):
        if not self.user:
            return
        self.version_seen = self.store.data_version()
        self.refresh_bookings()
        self.refresh_masters()
        self.safe_schedule()
        self.refresh_devotees()

    def poll(self):
        try:
            if self.user:
                if time.monotonic() - self.last_activity > IDLE_LOCK_MINUTES * 60:
                    self.lock()
                elif self.store.data_version() != self.version_seen:
                    self.refresh()  # only when something changed, e.g. a phone booking
        except Exception as ex:
            self.status.config(text=f'Refresh problem: {ex}')
        self.root.after(4000, self.poll)

    def backups_folder(self):
        return self.folder / 'backups'

    def backup(self):
        self.need('backup')
        dest = filedialog.asksaveasfilename(defaultextension='.sqlite3', initialfile=f'devseva-backup-{today()}.sqlite3')
        if dest:
            if Path(dest).resolve() == self.db_path.resolve():
                raise ValueError('Choose a different backup file.')
            self.store.backup(dest)
            messagebox.showinfo('Backup', 'Database backup saved. Copy it to a USB drive or other safe place.')

    def restore(self):
        self.need('restore')
        source = filedialog.askopenfilename(title='Choose a DevSeva backup to restore',
                                            initialdir=str(self.backups_folder()) if self.backups_folder().exists() else None,
                                            filetypes=[('DevSeva backup', '*.sqlite3 *.db'), ('All files', '*')])
        if not source:
            return
        count = Store.check_backup(source)
        if not messagebox.askyesno('Restore backup',
                                   f'Replace ALL current DevSeva data with this backup?\n\n{Path(source).name}\n'
                                   f'Bookings in the backup: {count}\n\n'
                                   'A safety copy of the current data is saved first in the "backups" folder. '
                                   'Mobile access will stop and everyone will need to log in again.', icon='warning'):
            return
        self.stop_mobile()
        self.close_windows()
        safety = self.store.restore(source, self.backups_folder(), self.actor)
        self.store = Store(self.db_path)
        messagebox.showinfo('Restore complete', f'Backup restored ({count} bookings).\n\nThe previous data was saved as:\n{safety}\n\n'
                            'Log in again. If the backup is from before staff logins existed, you will be asked to create an Admin.')
        self.lock()

    def export(self):
        self.need('reports')
        dest = filedialog.asksaveasfilename(defaultextension='.csv', initialfile='devseva-register.csv')
        if dest:
            self.store.export(dest)
            messagebox.showinfo('Export', 'Booking register saved. AED and INR remain separate.')

    # ------------------------------------------------------------------- staff
    def staff(self):
        self.need('staff')
        win = tk.Toplevel(self.root)
        win.title('Staff logins')
        win.geometry('720x460')
        win.transient(self.root)
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text='Admin: everything · Supervisor: refunds, cancellations, corrections, mobile access, backups · '
                  'Cashier: bookings and payments · Reception: bookings and devotees only', wraplength=680).pack(anchor='w')
        tree = self.table(frame, ('id', 'name', 'role', 'active'), ('ID', 'Name', 'Role', 'Active'), widths={'id': 50})
        def load():
            self.fill(tree, [(x['id'], (x['id'], x['name'], x['role'], 'Yes' if x['active'] else 'No')) for x in self.store.staff_list()])
        def add():
            def save(v):
                if v['pin'] != v['pin2']:
                    raise ValueError('The two PINs do not match.')
                self.store.add_staff(v['name'], v['role'], v['pin'], self.actor)
                load()
            w = self.form('Add staff login', [('name', 'Name', '', None), ('role', 'Role', 'Reception', list(security.ROLES)),
                                              ('pin', 'PIN (4–12 digits)', '', None), ('pin2', 'Repeat PIN', '', None)], save, parent=win)
            self.mask_pins(w)
        def edit():
            ident = self.selected(tree, 'staff login')
            row = next(x for x in self.store.staff_list() if x['id'] == ident)
            def save(v):
                self.store.update_staff(ident, v['role'], v['active'] == 'Yes', self.actor)
                load()
            self.form(f"Edit {row['name']}", [('role', 'Role', row['role'], list(security.ROLES)),
                                              ('active', 'Can log in', 'Yes' if row['active'] else 'No', ['Yes', 'No'])], save, parent=win)
        def reset():
            ident = self.selected(tree, 'staff login')
            def save(v):
                if v['pin'] != v['pin2']:
                    raise ValueError('The two PINs do not match.')
                self.store.set_pin(ident, v['pin'], self.actor)
                messagebox.showinfo(APP_NAME, 'PIN reset. The login is unlocked.', parent=win)
            w = self.form('Reset PIN', [('pin', 'New PIN', '', None), ('pin2', 'Repeat PIN', '', None)], save, parent=win)
            self.mask_pins(w)
        self.button_row(frame, [('Add staff', add), ('Change role / disable', edit), ('Reset PIN', reset)])
        load()
        return win

    @staticmethod
    def mask_pins(win):
        frame = win.winfo_children()[0]
        labels = [w for w in frame.winfo_children() if w.winfo_class() == 'TLabel']
        entries = [w for w in frame.winfo_children() if w.winfo_class() in ('TEntry', 'TCombobox')]
        for label, entry in zip(labels, entries):
            if 'PIN' in label.cget('text') and entry.winfo_class() == 'TEntry':
                entry.configure(show='•')

    # ------------------------------------------------------------------ mobile
    def stop_mobile(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            self.server = None
            self.server_info = None
            self.mobile_state.config(text='')

    def mobile(self):
        self.need('mobile')
        if self.server:
            if messagebox.askyesno('Mobile access', 'Stop mobile access? Phones will be logged out and the access code will change next time.'):
                self.stop_mobile()
            return
        if not messagebox.askyesno('Enable phone entry',
                                   'Connect phones and this laptop to a private, password-protected Wi-Fi or hotspot. '
                                   'Never use public Wi-Fi.\n\nStaff log in on their phone with the access code shown next, '
                                   'plus their own name and PIN. Enable phone entry?'):
            return
        addresses = security.local_addresses()
        cert = key = None
        try:
            cert, key = security.ensure_certificate(self.folder / 'tls', addresses)
        except Exception as ex:
            if not messagebox.askyesno('Encryption unavailable', f'{ex}\n\nStart WITHOUT encryption? Only do this on a network you fully trust.', icon='warning'):
                return
        self.server, self.server_info = start(self.store, 8765, cert, key)
        info = self.server_info
        self.mobile_state.config(text=f"📱 Phone entry ON ({'encrypted' if info['encrypted'] else 'NOT encrypted'})")
        win = tk.Toplevel(self.root)
        win.title('Phone entry details')
        frame = ttk.Frame(win, padding=16)
        frame.pack(fill='both', expand=True)
        urls = [f"{info['scheme']}://{ip}:8765" for ip in addresses] or [f"{info['scheme']}://<laptop Wi-Fi address>:8765"]
        ttk.Label(frame, text='1. On each phone, open:', font=('', 13, 'bold')).pack(anchor='w')
        for url in urls:
            ttk.Label(frame, text=url, font=('Menlo' if sys.platform == 'darwin' else 'Courier', 18, 'bold')).pack(anchor='w', padx=12)
        ttk.Label(frame, text='2. Access code:', font=('', 13, 'bold')).pack(anchor='w', pady=(12, 0))
        ttk.Label(frame, text=info['code'], font=('Menlo' if sys.platform == 'darwin' else 'Courier', 26, 'bold')).pack(anchor='w', padx=12)
        ttk.Label(frame, text='3. Staff enter their own name and PIN (add people under Staff logins).', font=('', 13, 'bold')).pack(anchor='w', pady=(12, 0))
        if info['encrypted']:
            text = ('The connection is encrypted with this laptop\'s own certificate. The first time, the phone warns '
                    '"Your connection is not private" / "This connection is not private". Tap Advanced / Show details → Proceed / visit website.\n\n'
                    'To be sure it is this laptop, the certificate\'s SHA-256 fingerprint (in the browser\'s certificate details) should start with:\n'
                    + security.fingerprint(cert)[:47])
        else:
            text = 'WARNING: this session is NOT encrypted. Use only on a private network you trust.'
        ttk.Label(frame, text=text, wraplength=620, justify='left').pack(anchor='w', pady=12)
        ttk.Label(frame, text='Allow incoming connections if the Mac firewall asks. Keep the laptop awake. '
                  'Stopping phone entry logs every phone out.', wraplength=620, foreground='#555').pack(anchor='w')
        return win

    def close(self):
        self.stop_mobile()
        try:
            self.store.auto_backup(self.backups_folder(), keep=AUTO_BACKUPS_KEPT)
        except Exception as ex:
            if not messagebox.askyesno(APP_NAME, f'The automatic backup failed: {ex}\n\nQuit anyway?'):
                return
        for path in self.previews:
            try:
                os.remove(path)
            except OSError:
                pass
        self.root.destroy()


def self_test():
    """Quick check used by the build script and for support: no window, no real data touched."""
    import shutil
    checks = []
    folder = Path(tempfile.mkdtemp(prefix='devseva-selftest-'))
    try:
        store = Store(folder / 'test.sqlite3')
        store.add_staff('Self Test', 'Admin', '4821')
        checks.append(('database and PIN login', store.login('Self Test', '4821')['role'] == 'Admin'))
        event = store.event(dict(name='Test', day=today(), place='Here', currency='INR'))
        seva = store.seva(dict(event_id=event, name='Pooja', price='10', kind='Seva'))
        bid = store.book(dict(request_key='t', event_id=event, devotee='Test', items=[dict(seva_id=seva, quantity=1)]), 'Self test')
        checks.append(('booking and receipt', 'Pooja' in receipt(store.detail(bid))))
        checks.append(('phone page file', Path(__import__('mobile').page_path()).exists()))
        try:
            security.ensure_certificate(folder / 'tls', ['127.0.0.1'])
            checks.append(('encryption certificate', True))
        except Exception as ex:
            checks.append((f'encryption certificate ({ex})', False))
        checks.append(('Tk version ' + str(tk.TkVersion), tk.TkVersion >= 8.6))
    finally:
        shutil.rmtree(folder, ignore_errors=True)
    for name, ok in checks:
        print(('OK    ' if ok else 'FAIL  ') + name)
    return 0 if all(ok for _, ok in checks) else 1


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(self_test())
    root = tk.Tk()
    App(root)
    root.mainloop()
