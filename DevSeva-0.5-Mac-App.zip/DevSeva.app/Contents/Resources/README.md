# DevSeva / ದೇವಸೇವೆ — offline temple desk, version 0.5

DevSeva is an offline desktop app for temples, ashrams and religious event committees. It manages daily poojas, special sevas, festival bookings, devotee records, cashier collection and reports. It runs on one laptop with a local SQLite database. Phones can optionally enter bookings over a private Wi-Fi network served by that laptop. No internet, hosting account or cloud database is used during operation.

This is a working prototype (formerly "Seva Desk"), not a signed, sale-ready installer. It uses the Python 3.10+ and Tk already installed on the Mac.

## What's new in 0.5

**Rebrand.** The app is now called DevSeva. It still uses your existing database at `~/Library/Application Support/SevaDeskPrototype/seva-desk.sqlite3`, so every earlier booking stays in place. The folder name was deliberately left unchanged.

**Devotee register (Devotees tab).** Each family is saved with a phone number, gotra, address and notes. Each family member is saved with their English and Kannada name, relation, rashi and nakshatra. You can search by name, any member's name, gotra or phone digits. A possible duplicate phone number is flagged when you add a family. **Booking history** shows every booking linked to a family, and **New booking for family** opens a booking with the details filled in. Bookings made before 0.5 are not linked to any family automatically.

**A slip for each person.** In a booking, every seva line has a **Slip for** choice, either the main devotee or any family member. That person's name, Kannada name, rashi and nakshatra print on their own slip. **Add every member** adds one slip per active family member. The cashier summary shows who each line is for. Slips keep the details as they were when booked, so later register edits don't change printed history.

**Walk-in devotees.** Walk-ins can still be booked without the register. Tick **Save this new devotee to the register** to add them as a new family during the same save. A retry never creates the family twice.

**Daily poojas and special sevas.** In Masters, an event or calendar is one of two types. **Once** is a festival or event on one date; its bookings are for that date. **Daily** is a regular temple pooja calendar with a start date, an optional end date and the days it runs (for example "All" or "Mon, Fri"); bookings choose a pooja date within those rules. Any seva can have a **per-day limit** (0 means no limit). The limit is checked safely even when several phones book at once, and cancelled bookings free their slot. Remaining slots are shown while booking.

**Postponed festivals.** If you change a Once event's date, its active bookings move to the new date and the change is written to the audit log. Receipts show the new pooja date, while the stored event snapshot keeps the original details.

**Archive.** Events and sevas can be archived. They disappear from new bookings on the laptop and phones but stay in history and reports. **Restore** brings them back.

**Pooja schedule tab.** The priest's day sheet lists every non-cancelled slip for a date, grouped by seva, with name, Kannada name, gotra, rashi, nakshatra and payment state. You can move day by day and filter by event. **Print priest sheet** opens a printable A4 page.

**Reports tab.** Choose a date range (with Today, This week, This month and This year shortcuts) and an optional event filter. The report shows:

- cash collected by the date payment was received, split by payment method, by seva and by day;
- bookings entered in the period, cancellations and in-kind slips;
- the unpaid balance;
- sevas scheduled in the period by pooja date.

**Print report** opens a printable page. **Export slip-level CSV** writes one row per slip. AED and INR are never converted or added together.

**Bookings tab.** You can search by name, booking number or phone digits, and double-click a booking to preview it. The list now shows the pooja date and slip count, and the footer shows today's collections and the unpaid balance for all dates.

**Phones.** The phone page offers the same devotee search, per-member slips, "every member" button, pooja date picker, remaining slots, gotra and save-to-register option. Archived events are hidden. When a booking is rejected (for example because a seva is full), the phone says nothing was saved and lets you correct the booking. Only connection or server failures keep the "Retry same booking" lock, so a booking is never duplicated.

## Daily use

1. **Masters:** add your festival (Type: Once) or temple calendar (Type: Daily), then its sevas, sponsorships and in-kind categories.
2. **Devotees:** add regular devotee families and their members.
3. **New booking:** choose the event, then the pooja date if it's a Daily calendar. Use **Find…** to pick a family, or type a walk-in devotee. Add seva lines, choosing who each slip is for, then **Save and preview slips** and print from the browser. Click **Confirm printed** only after the paper has actually printed.
4. **Cashier:** select the booking, then **Receive payment**. Payment is never recorded automatically when slips print.
5. **Pooja schedule:** print the priest sheet for the day.
6. **Reports:** review collections at the end of the day, then use **Backup database**.

Unpaid bookings can be cancelled with a reason. Paid refunds and corrections are intentionally not implemented yet.

## Phones and hotspot

Keep the laptop and phones on the same private, password-protected Wi-Fi or hotspot. Click **Mobile access**, then open the displayed address (port 8765) on each phone and enter the reception or cashier key plus the operator's name. Both roles can search the devotee register, which includes names, gotra and phone numbers, so give keys only to trusted volunteers. Stop mobile access when finished; restarting it changes the keys. The traffic is unencrypted local HTTP, so never use public Wi-Fi or set up port forwarding.

## Data and backup

The database is `SevaDeskPrototype/seva-desk.sqlite3` in `~/Library/Application Support` (Windows: Local AppData). Use **Backup database** after each session and copy the file to a secure external drive. The backup includes the devotee register, glossary and audit log.

To restore:

1. Quit all copies of the app.
2. Keep a copy of the whole data folder.
3. Move the database and its `-wal`/`-shm` files aside.
4. Copy the backup into the folder, named `seva-desk.sqlite3`.
5. Open the app and check the register.

Version 0.5 upgrades the database automatically and additively: it adds new tables and columns, and existing bookings keep their amounts, status and receipt details. Once upgraded, the database should be opened only with 0.5 or later. The old 0.4 app will not show the new information and has not been tested against an upgraded database.

The database and backups are not encrypted. Operator names are self-entered, not verified staff logins. Receipt, schedule and report previews are temporary files that are deleted when the app closes normally.

## Kannada

Event and seva names use an offline glossary that translates by meaning, and corrections you save are remembered. Devotee names get an editable phonetic suggestion. Always have the Kannada spelling checked with the devotee, and have a fluent reader review public wording.

## Verification

Run `python3 -m unittest test_core test_kannada test_v05` from the Resources folder. The 28 tests cover:

- receipts, escaping, retries and parallel entry;
- price permissions, payment and cancellation rules, in-kind entries, backups and mobile roles;
- the Kannada glossary;
- daily-pooja date rules, per-day limits under concurrent booking, per-person slips and register search;
- save-to-register retries, archiving, postponed festivals, schedules, reports and currency separation;
- the new phone endpoints and the upgrade of a v0.4 database.

The desktop screens and the phone page were also run end to end in a test environment, on Linux with Python 3.12 and Chromium. Native macOS behaviour, your phones' browsers, Kannada font rendering on your Mac and physical thermal printers still need testing on your devices.

## Still to do before commercial release

- **Staff and security:** individual staff PINs, supervisor approval and encrypted phone transport.
- **Money:** paid refunds and corrections, and payment reconciliation.
- **Printing:** automatic thermal printing with a tested printer.
- **Data safety:** restore from inside the app, and database encryption.
- **Devotee details:** gotra is recorded per booking/family, not per member, and older bookings could be linked to register families.
- **Distribution:** signed and notarised Mac and Windows installers that don't need Python, plus offline licensing.
