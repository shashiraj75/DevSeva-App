"""DevSeva desktop app. Run with Python 3.10+ on macOS or Windows: python3 app.py"""
import datetime as dt
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import uuid
import webbrowser
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
from core import (Store, receipt, schedule_html, report_html, report_text, money, fmt, weekday_text,
                  APP_NAME, APP_NAME_KN, VERSION, CURRENCIES, KINDS, METHODS, RECURRENCES, RELATIONS, ADMIN)
from mobile import start
from kannada import bind_suggestion, translate_label, suggest, RASHIS, NAKSHATRAS

MAX_ROWS = 1000


def data_folder():
    # Kept from Seva Desk so upgrades keep using the existing database.
    if sys.platform == 'win32':
        base = Path(os.environ.get('LOCALAPPDATA', str(Path.home())))
    elif sys.platform == 'darwin':
        base = Path.home() / 'Library' / 'Application Support'
    else:
        base = Path.home() / '.local' / 'share'
    folder = base / 'SevaDeskPrototype'
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def today():
    return dt.date.today().isoformat()


class App:
    def __init__(self, root, folder=None):
        self.root = root
        self.folder = Path(folder) if folder else data_folder()
        self.store = Store(self.folder / 'seva-desk.sqlite3')
        self.server = None
        self.previews = []
        root.title(f'{APP_NAME} / {APP_NAME_KN} — offline temple desk {VERSION}')
        root.geometry('1240x800')
        root.minsize(980, 640)
        ttk.Style().configure('TButton', padding=6)
        head = ttk.Frame(root)
        head.pack(fill='x', padx=18, pady=(14, 2))
        ttk.Label(head, text=f'{APP_NAME} / {APP_NAME_KN}', font=('', 22, 'bold')).pack(side='left')
        ttk.Label(head, text='   Daily poojas • Festival sevas • Devotee register • Offline').pack(side='left')
        bar = ttk.Frame(root)
        bar.pack(fill='x', padx=15, pady=8)
        for title, command in [('New booking / ನೋಂದಣಿ', self.booking), ('Mobile access', self.mobile),
                               ('Backup database', self.backup), ('Export register CSV', self.export)]:
            ttk.Button(bar, text=title, command=lambda c=command: self.safe(c)).pack(side='left', padx=3)
        self.width = tk.StringVar(value='80')
        ttk.Label(bar, text='Slip paper mm:').pack(side='left', padx=8)
        ttk.Combobox(bar, textvariable=self.width, values=['58', '80'], width=4, state='readonly').pack(side='left')
        self.tabs = ttk.Notebook(root)
        self.tabs.pack(fill='both', expand=True, padx=15, pady=5)
        self.build_bookings()
        self.build_schedule()
        self.build_devotees()
        self.build_reports()
        self.build_masters()
        self.status = ttk.Label(root, text='Keep the laptop awake during mobile entry. Receipts open in your browser for printing.')
        self.status.pack(anchor='w', padx=15, pady=6)
        root.protocol('WM_DELETE_WINDOW', self.close)
        self.refresh()
        self.refresh_devotees()
        self.poll()

    # ----------------------------------------------------------------- helpers
    def safe(self, command, parent=None):
        try:
            return command()
        except Exception as ex:
            messagebox.showerror(APP_NAME, str(ex), parent=parent or self.root)

    def button_row(self, parent, buttons):
        row = ttk.Frame(parent)
        row.pack(fill='x', pady=6)
        for title, command in buttons:
            ttk.Button(row, text=title, command=lambda c=command: self.safe(c)).pack(side='left', padx=3)
        return row

    def table(self, parent, columns, labels, height=12, widths=None, expand=True):
        frame = ttk.Frame(parent)
        frame.pack(fill='both', expand=expand, pady=4)
        tree = ttk.Treeview(frame, columns=columns, show='headings', height=height, selectmode='browse')
        for i, (column, label) in enumerate(zip(columns, labels)):
            tree.heading(column, text=label)
            tree.column(column, width=(widths or {}).get(column, 120), minwidth=40, stretch=True)
        scroll = ttk.Scrollbar(frame, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        tree.pack(fill='both', expand=True)
        return tree

    def selected(self, tree=None, what='row'):
        chosen = (tree or self.tree).selection()
        if not chosen:
            raise ValueError(f'Select a {what} first.')
        return int(chosen[0])

    @staticmethod
    def fill(tree, rows):
        keep = tree.selection()
        tree.delete(*tree.get_children())
        for iid, values in rows:
            tree.insert('', 'end', iid=str(iid), values=values)
        if keep and tree.exists(keep[0]):
            tree.selection_set(keep[0])

    def open_html(self, content, prefix='devseva-'):
        handle, path = tempfile.mkstemp(prefix=prefix, suffix='.html')
        with os.fdopen(handle, 'w', encoding='utf-8') as f:
            f.write(content)
        self.previews.append(path)
        webbrowser.open(Path(path).as_uri())

    def event_choices(self, active_only=True, include_all=False):
        events = self.store.catalog(active_only)['events']
        options = {'All events': None} if include_all else {}
        options.update({f"{e['id']} · {e['name']} ({e['currency']})": e['id'] for e in events})
        return options

    def form(self, title, fields, on_save, kannada=None, parent=None):
        """fields: (key, label, value, choices). kannada: (source, target, 'label' | 'name')."""
        win = tk.Toplevel(parent or self.root)
        win.title(title)
        win.transient(parent or self.root)
        frame = ttk.Frame(win, padding=18)
        frame.pack(fill='both', expand=True)
        values = {}
        for i, (key, label, value, choices) in enumerate(fields):
            ttk.Label(frame, text=label).grid(row=i, column=0, sticky='w', padx=4, pady=6)
            var = tk.StringVar(value=str(value))
            values[key] = var
            if choices:
                widget = ttk.Combobox(frame, textvariable=var, values=choices, state='readonly', width=40)
            else:
                widget = ttk.Entry(frame, textvariable=var, width=43)
            widget.grid(row=i, column=1, sticky='ew', padx=4, pady=6)
        n = len(fields)
        if kannada:
            source, target, mode = kannada
            if mode == 'label':
                saved = self.store.label_dictionary()
                convert = lambda text: translate_label(text, saved)
            else:
                convert = suggest
            reset = bind_suggestion(values[source], values[target], convert)
            ttk.Button(frame, text='Use Kannada glossary' if mode == 'label' else 'Regenerate Kannada',
                       command=reset).grid(row=n + 1, column=1, sticky='e')
            hint = ttk.Label(frame, text='', wraplength=460)
            hint.grid(row=n + 2, column=0, columnspan=2, pady=8)
            def explain(*_):
                if mode != 'label':
                    hint.config(text='Phonetic suggestion only. Check the Kannada spelling with the devotee.')
                elif convert(values[source].get()):
                    hint.config(text='Offline glossary available. Review the Kannada wording. Corrections are remembered when saved.')
                else:
                    hint.config(text='No glossary match. Enter the Kannada wording once; it will be remembered.')
            values[source].trace_add('write', explain)
            explain()
        def save():
            try:
                on_save({k: v.get() for k, v in values.items()})
                win.destroy()
                self.refresh()
                self.refresh_devotees()
            except Exception as ex:
                messagebox.showerror(title, str(ex), parent=win)
        ttk.Button(frame, text='Save / ಉಳಿಸಿ', command=save).grid(row=n, column=1, sticky='e', pady=12)
        return win

    # ---------------------------------------------------------------- bookings
    def build_bookings(self):
        tab = ttk.Frame(self.tabs, padding=6)
        self.tabs.add(tab, text='Bookings & cashier / ನೋಂದಣಿ')
        top = ttk.Frame(tab)
        top.pack(fill='x')
        ttk.Label(top, text='Search name, booking no. or phone:').pack(side='left')
        self.booking_filter = tk.StringVar()
        entry = ttk.Entry(top, textvariable=self.booking_filter, width=30)
        entry.pack(side='left', padx=6)
        self.booking_filter.trace_add('write', lambda *_: self.safe(self.refresh_bookings))
        self.tree = self.table(tab, ('id', 'date', 'event', 'devotee', 'slips', 'currency', 'amount', 'status', 'print'),
                               ('Booking', 'Pooja date', 'Event', 'Devotee', 'Slips', 'Cur.', 'Total', 'Payment', 'Print queue'),
                               widths={'id': 70, 'slips': 50, 'currency': 50, 'date': 95, 'event': 220, 'devotee': 220})
        self.tree.bind('<Double-1>', lambda _: self.safe(self.preview))
        self.button_row(tab, [('Preview / print slips', self.preview), ('Confirm printed', self.printed),
                              ('Receive payment', self.pay), ('Cancel unpaid booking', self.void), ('Refresh', self.refresh)])
        self.summary = ttk.Label(tab, text='')
        self.summary.pack(anchor='w', pady=6)

    def refresh_bookings(self):
        pending = {x['booking_id'] for x in self.store.queue()}
        query = self.booking_filter.get().strip().casefold()
        digits = ''.join(c for c in query if c.isdigit())
        rows = []
        with self.store.connect() as db:
            slips = dict(db.execute('SELECT booking_id, COUNT(*) FROM items GROUP BY booking_id').fetchall())
        for b in self.store.bookings():
            if query and not (query in (b['devotee'] + ' ' + b['devotee_kn']).casefold() or query == str(b['id'])
                              or (len(digits) >= 3 and digits in ''.join(c for c in b['phone'] if c.isdigit()))):
                continue
            e = json.loads(b['snapshot'])
            rows.append((b['id'], (b['id'], b['service_date'], e['name'], b['devotee'], slips.get(b['id'], 0), e['currency'],
                                   fmt(b['total']), b['status'], 'Pending' if b['id'] in pending else 'Confirmed')))
            if len(rows) >= MAX_ROWS:
                break
        self.fill(self.tree, rows)
        rep = self.store.report(today(), today())
        collected = ' · '.join(f'{c} {fmt(v)}' for c, v in sorted(rep['collected'].items())) or 'nothing yet'
        unpaid = ' · '.join(f'{c} {fmt(v)}' for c, v in sorted(rep['outstanding'].items()) if v) or 'none'
        self.summary.config(text=f'Collected today: {collected}     |     Unpaid (all dates): {unpaid}'
                            + (f'     |     Showing latest {MAX_ROWS} matches' if len(rows) >= MAX_ROWS else ''))

    def preview(self):
        b = self.store.detail(self.selected(what='booking'))
        self.open_html(receipt(b, int(self.width.get())), 'devseva-receipt-')

    def printed(self):
        bid = self.selected(what='booking')
        if messagebox.askyesno('Confirm printing', 'Have all seva slips and the cashier summary physically printed?'):
            self.store.printed(bid)
            self.refresh()

    def pay(self):
        b = self.store.detail(self.selected(what='booking'))
        if b['status'] != 'UNPAID':
            raise ValueError('Select an unpaid booking.')
        if b['total'] <= 0:
            raise ValueError('No cash is due on this booking.')
        def save(v):
            if not messagebox.askyesno('Confirm payment', f"Have you received {b['event']['currency']} {fmt(b['total'])} from {b['devotee']}?"):
                raise ValueError('Payment not recorded.')
            self.store.pay(b['id'], ADMIN, v['method'])
        self.form('Receive payment', [('method', 'Payment method', 'Cash', list(METHODS))], save)

    def void(self):
        bid = self.selected(what='booking')
        reason = simpledialog.askstring('Cancel unpaid booking', 'Reason (record stays in the audit log):', parent=self.root)
        if reason:
            self.store.void(bid, reason)
            self.refresh()

    # ------------------------------------------------------------ new booking
    def booking(self, family_id=None):
        cat = self.store.catalog(active_only=True)
        if not cat['sevas']:
            raise ValueError('Create an event or daily pooja calendar and its sevas in Masters first.')
        events = {e['id']: e for e in cat['events']}
        labels = {f"{e['id']} · {e['name']} ({e['currency']})": e['id'] for e in cat['events']
                  if any(s['event_id'] == e['id'] for s in cat['sevas'])}
        win = tk.Toplevel(self.root)
        win.title('New booking / ಸೇವಾ ನೋಂದಣಿ')
        win.geometry('820x860')
        frame = ttk.Frame(win, padding=14)
        frame.pack(fill='both', expand=True)
        frame.columnconfigure(1, weight=1)
        v = {k: tk.StringVar() for k in ('event', 'date', 'family', 'devotee', 'devotee_kn', 'phone', 'gotra',
                                          'rashi', 'nakshatra', 'note', 'seva', 'person', 'qty', 'amount')}
        save_new = tk.BooleanVar(value=False)
        state = {'family_id': None, 'members': {}, 'lines': []}
        r = 0
        def row(label, widget, extra=None):
            nonlocal r
            ttk.Label(frame, text=label).grid(row=r, column=0, sticky='w', pady=4)
            widget.grid(row=r, column=1, sticky='ew', pady=4)
            if extra:
                extra.grid(row=r, column=2, sticky='w', padx=6)
            r += 1
            return widget
        row('Event / pooja calendar', ttk.Combobox(frame, textvariable=v['event'], values=list(labels), state='readonly'))
        date_entry = row('Pooja date YYYY-MM-DD', ttk.Entry(frame, textvariable=v['date']))
        date_hint = ttk.Label(frame, text='', foreground='#555')
        date_hint.grid(row=r, column=1, sticky='w')
        r += 1
        fam_buttons = ttk.Frame(frame)
        row('Devotee register', ttk.Entry(frame, textvariable=v['family'], state='readonly'), fam_buttons)
        row('Devotee name (English)', ttk.Entry(frame, textvariable=v['devotee']))
        row('Kannada name (editable)', ttk.Entry(frame, textvariable=v['devotee_kn']))
        row('Phone (optional)', ttk.Entry(frame, textvariable=v['phone']))
        row('Gotra / ಗೋತ್ರ (optional)', ttk.Entry(frame, textvariable=v['gotra']))
        row('Rashi / ರಾಶಿ', ttk.Combobox(frame, textvariable=v['rashi'], values=[''] + RASHIS, state='readonly'))
        row('Nakshatra / ನಕ್ಷತ್ರ', ttk.Combobox(frame, textvariable=v['nakshatra'], values=[''] + NAKSHATRAS, state='readonly'))
        row('Notes / in-kind details', ttk.Entry(frame, textvariable=v['note']))
        save_check = ttk.Checkbutton(frame, text='Save this new devotee to the register', variable=save_new)
        save_check.grid(row=r, column=1, sticky='w')
        reset_kn = bind_suggestion(v['devotee'], v['devotee_kn'])
        ttk.Button(frame, text='Regenerate Kannada', command=reset_kn).grid(row=r, column=2, sticky='w', padx=6)
        r += 1
        ttk.Separator(frame).grid(row=r, column=0, columnspan=3, sticky='ew', pady=10)
        r += 1
        seva_combo = row('Seva', ttk.Combobox(frame, textvariable=v['seva'], state='readonly'))
        avail = ttk.Label(frame, text='', foreground='#555')
        avail.grid(row=r, column=1, sticky='w')
        r += 1
        person_combo = row('Slip for (family member)', ttk.Combobox(frame, textvariable=v['person'], state='readonly'))
        row('Quantity (one slip each)', ttk.Entry(frame, textvariable=v['qty']))
        row('Amount each (admin editable)', ttk.Entry(frame, textvariable=v['amount']))
        choices = {}
        MAIN = 'Main devotee (details above)'

        def current_event():
            return events[labels[v['event'].get()]]

        def set_family(fid):
            fam = self.store.family_detail(fid)
            active = [m for m in fam['members'] if m['active']]
            state['family_id'] = fid
            state['members'] = {f"{m['name']} ({m['relation']})": m for m in active}
            main = next((m for m in active if m['relation'] == 'Self'), active[0] if active else None)
            v['family'].set(f"#{fid} · {fam['head']} · {len(active)} member(s)")
            v['devotee'].set(main['name'] if main else fam['head'])
            v['devotee_kn'].set(main['kannada'] if main else '')
            v['rashi'].set(main['rashi'] if main else '')
            v['nakshatra'].set(main['nakshatra'] if main else '')
            v['phone'].set(fam['phone'])
            v['gotra'].set(fam['gotra'])
            save_new.set(False)
            save_check.state(['disabled'])
            person_combo.config(values=[MAIN] + list(state['members']))
            v['person'].set(MAIN)
            if state['lines'] and any(l.get('member_id') for l in state['lines']):
                clear()

        def clear_family():
            state['family_id'] = None
            state['members'] = {}
            v['family'].set('Not selected — walk-in devotee')
            save_check.state(['!disabled'])
            person_combo.config(values=[MAIN])
            v['person'].set(MAIN)
            if any(l.get('member_id') for l in state['lines']):
                clear()

        ttk.Button(fam_buttons, text='Find…', command=lambda: self.safe(lambda: self.pick_family(win, set_family), win)).pack(side='left')
        ttk.Button(fam_buttons, text='Clear', command=clear_family).pack(side='left')

        def update_availability(*_):
            s = choices.get(v['seva'].get())
            if not s or not s['daily_limit']:
                avail.config(text='')
                return
            try:
                left = self.store.availability(s['event_id'], v['date'].get())[s['id']]
                pending = sum(l['quantity'] for l in state['lines'] if l['seva_id'] == s['id'])
                avail.config(text=f"{left - pending} of {s['daily_limit']} slots free on {v['date'].get()}")
            except (ValueError, KeyError):
                avail.config(text=f"Limit {s['daily_limit']} per day — enter a valid pooja date")

        def price(*_):
            s = choices.get(v['seva'].get())
            if s:
                v['amount'].set(f"{s['price'] / 100:.2f}")
            update_availability()

        def event_changed(*_):
            clear()
            e = current_event()
            choices.clear()
            choices.update({f"{s['name']} / {s['kannada']}  ·  {s['kind']}": s for s in cat['sevas'] if s['event_id'] == e['id']})
            seva_combo.config(values=list(choices))
            v['seva'].set(next(iter(choices), ''))
            if e['recurrence'] == 'Daily':
                date_entry.state(['!disabled'])
                if not v['date'].get() or v['date'].get() < e['day']:
                    v['date'].set(max(today(), e['day']))
                end = f" until {e['end_day']}" if e['end_day'] else ''
                date_hint.config(text=f"Daily pooja · days: {weekday_text(e['weekdays'])} · from {e['day']}{end}")
            else:
                v['date'].set(e['day'])
                date_entry.state(['disabled'])
                date_hint.config(text=f"Festival / event on {e['day']} at {e['place']}")
            price()

        cart = tk.Listbox(frame, height=7)
        total = ttk.Label(frame, text='', font=('', 13, 'bold'))

        def redraw():
            cart.delete(0, 'end')
            for l in state['lines']:
                cart.insert('end', f"{l['quantity']} × {l['label']}  —  for {l['who']}  =  {fmt(money(l['amount']) * l['quantity'])}")
            amount = sum(money(l['amount']) * l['quantity'] for l in state['lines'])
            total.config(text=f"Total: {current_event()['currency']} {fmt(amount)}" if state['lines'] else '')
            update_availability()

        def add():
            s = choices.get(v['seva'].get())
            if not s:
                raise ValueError('Choose a seva.')
            text = v['qty'].get().strip()
            if not text.isdigit():
                raise ValueError('Quantity must be a whole number.')
            q, p = int(text), money(v['amount'].get())
            if q < 1 or sum(l['quantity'] for l in state['lines']) + q > 100:
                raise ValueError('Use 1–100 total slips.')
            if s['kind'] == 'In-kind' and p:
                raise ValueError('In-kind contributions must have zero cash amount.')
            member = state['members'].get(v['person'].get())
            state['lines'].append({'seva_id': s['id'], 'quantity': q, 'amount': f'{p / 100:.2f}',
                                   'member_id': member['id'] if member else None, 'label': s['name'],
                                   'who': member['name'] if member else (v['devotee'].get() or 'main devotee')})
            v['qty'].set('1')
            redraw()

        def remove():
            chosen = cart.curselection()
            if not chosen:
                raise ValueError('Select a line in the list to remove.')
            del state['lines'][chosen[0]]
            redraw()

        def clear():
            state['lines'].clear()
            redraw()

        buttons = ttk.Frame(frame)
        buttons.grid(row=r, column=1, sticky='e')
        ttk.Button(buttons, text='Add seva line', command=lambda: self.safe(add, win)).pack(side='left', padx=3)
        ttk.Button(buttons, text='Add every member', command=lambda: self.safe(add_all, win)).pack(side='left', padx=3)
        r += 1
        cart.grid(row=r, column=0, columnspan=3, sticky='ew', pady=6)
        r += 1
        total.grid(row=r, column=0, columnspan=2, sticky='w')
        r += 1

        def add_all():
            if not state['members']:
                raise ValueError('Select a devotee family from the register first.')
            before = v['person'].get()
            for label in list(state['members']):
                v['person'].set(label)
                add()
            v['person'].set(before)

        key = str(uuid.uuid4())

        def save():
            if not state['lines']:
                raise ValueError('Add at least one seva line.')
            data = {k: v[k].get() for k in ('devotee', 'devotee_kn', 'phone', 'gotra', 'rashi', 'nakshatra', 'note')}
            data.update(request_key=key, event_id=current_event()['id'], service_date=v['date'].get(),
                        family_id=state['family_id'], save_devotee=bool(save_new.get()) and not state['family_id'],
                        items=[{k: l[k] for k in ('seva_id', 'quantity', 'amount', 'member_id')} for l in state['lines']])
            bid = self.store.book(data, ADMIN, True)
            win.destroy()
            self.booking_filter.set('')
            self.refresh()
            self.refresh_devotees()
            self.tabs.select(0)
            self.tree.selection_set(str(bid))
            self.tree.see(str(bid))
            self.preview()

        actions = ttk.Frame(frame)
        actions.grid(row=r, column=0, columnspan=3, sticky='ew', pady=10)
        ttk.Button(actions, text='Remove selected line', command=lambda: self.safe(remove, win)).pack(side='left', padx=3)
        ttk.Button(actions, text='Clear lines', command=clear).pack(side='left', padx=3)
        ttk.Button(actions, text='Save and preview slips', command=lambda: self.safe(save, win)).pack(side='right', padx=3)

        v['qty'].set('1')
        v['event'].trace_add('write', event_changed)
        v['date'].trace_add('write', update_availability)
        seva_combo.bind('<<ComboboxSelected>>', price)
        v['event'].set(next(iter(labels)))
        if family_id:
            set_family(family_id)
        else:
            clear_family()
        return win

    def pick_family(self, parent, on_pick):
        win = tk.Toplevel(parent)
        win.title('Find devotee / ಭಕ್ತರ ಹುಡುಕಾಟ')
        win.geometry('720x460')
        win.transient(parent)
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill='both', expand=True)
        query = tk.StringVar()
        top = ttk.Frame(frame)
        top.pack(fill='x')
        ttk.Label(top, text='Name, family member, gotra or phone digits:').pack(side='left')
        entry = ttk.Entry(top, textvariable=query, width=30)
        entry.pack(side='left', padx=6)
        entry.focus_set()
        tree = self.table(frame, ('id', 'head', 'phone', 'gotra', 'members'), ('ID', 'Family', 'Phone', 'Gotra', 'Members'),
                          widths={'id': 50, 'members': 260})
        def search(*_):
            self.fill(tree, [(f['id'], (f['id'], f['head'], f['phone'], f['gotra'],
                                        ', '.join(m['name'] for m in f['members'] if m['active'])))
                             for f in self.store.families(query.get(), 200)])
        def choose(*_):
            fid = self.selected(tree, 'devotee family')
            win.destroy()
            on_pick(fid)
        query.trace_add('write', search)
        tree.bind('<Double-1>', lambda _: self.safe(choose, win))
        ttk.Button(frame, text='Use selected devotee', command=lambda: self.safe(choose, win)).pack(anchor='e')
        search()

    # ---------------------------------------------------------------- schedule
    def build_schedule(self):
        tab = ttk.Frame(self.tabs, padding=6)
        self.tabs.add(tab, text='Pooja schedule / ಪೂಜಾ ಪಟ್ಟಿ')
        top = ttk.Frame(tab)
        top.pack(fill='x')
        self.sched_date = tk.StringVar(value=today())
        self.sched_event = tk.StringVar(value='All events')
        ttk.Label(top, text='Date:').pack(side='left')
        ttk.Button(top, text='◀', width=3, command=lambda: self.safe(lambda: self.shift_day(-1))).pack(side='left')
        ttk.Entry(top, textvariable=self.sched_date, width=12).pack(side='left', padx=3)
        ttk.Button(top, text='▶', width=3, command=lambda: self.safe(lambda: self.shift_day(1))).pack(side='left')
        ttk.Button(top, text='Today', command=lambda: self.sched_date.set(today())).pack(side='left', padx=4)
        ttk.Label(top, text='   Event:').pack(side='left')
        self.sched_combo = ttk.Combobox(top, textvariable=self.sched_event, state='readonly', width=36)
        self.sched_combo.pack(side='left', padx=4)
        ttk.Button(top, text='Print priest sheet', command=lambda: self.safe(self.print_schedule)).pack(side='left', padx=8)
        self.sched_count = ttk.Label(tab, text='')
        self.sched_count.pack(anchor='w', pady=4)
        self.sched_tree = self.table(tab, ('seva', 'person', 'kn', 'gotra', 'rashi', 'nakshatra', 'booking', 'payment'),
                                     ('Seva', 'Name', 'Kannada', 'Gotra', 'Rashi', 'Nakshatra', 'Booking', 'Payment'),
                                     widths={'booking': 70, 'payment': 70})
        self.sched_date.trace_add('write', lambda *_: self.safe_schedule())
        self.sched_event.trace_add('write', lambda *_: self.safe_schedule())

    def shift_day(self, days):
        day = dt.date.fromisoformat(self.sched_date.get().strip()) + dt.timedelta(days=days)
        self.sched_date.set(day.isoformat())

    def schedule_rows(self):
        options = self.event_choices(active_only=False, include_all=True)
        return self.store.schedule(self.sched_date.get(), options.get(self.sched_event.get()))

    def safe_schedule(self):
        try:
            rows = self.schedule_rows()
        except ValueError:
            self.sched_count.config(text='Enter a date as YYYY-MM-DD.')
            self.fill(self.sched_tree, [])
            return
        self.fill(self.sched_tree, [(r['id'], (r['name'], r['person'], r['person_kn'], r['gotra'], r['rashi'], r['nakshatra'],
                                               r['booking'], 'Paid' if r['status'] == 'PAID' else ('In-kind' if r['kind'] == 'In-kind' else 'Due')))
                                    for r in rows])
        counts = {}
        for r in rows:
            counts[r['name']] = counts.get(r['name'], 0) + 1
        day = dt.date.fromisoformat(self.sched_date.get().strip())
        self.sched_count.config(text=f"{day:%A %d %B %Y}: {len(rows)} sevas   " + '  ·  '.join(f'{k}: {n}' for k, n in sorted(counts.items())))

    def print_schedule(self):
        self.open_html(schedule_html(self.sched_date.get().strip(), self.schedule_rows()), 'devseva-schedule-')

    # ---------------------------------------------------------------- devotees
    def build_devotees(self):
        tab = ttk.Frame(self.tabs, padding=6)
        self.tabs.add(tab, text='Devotees / ಭಕ್ತರು')
        top = ttk.Frame(tab)
        top.pack(fill='x')
        ttk.Label(top, text='Search name, member, gotra or phone:').pack(side='left')
        self.dev_query = tk.StringVar()
        ttk.Entry(top, textvariable=self.dev_query, width=30).pack(side='left', padx=6)
        self.dev_query.trace_add('write', lambda *_: self.safe(self.refresh_devotees))
        self.dev_count = ttk.Label(top, text='')
        self.dev_count.pack(side='left', padx=10)
        self.fam_tree = self.table(tab, ('id', 'head', 'phone', 'gotra', 'members', 'bookings'),
                                   ('ID', 'Family / devotee', 'Phone', 'Gotra', 'Members', 'Bookings'), height=9,
                                   widths={'id': 50, 'members': 70, 'bookings': 70, 'head': 260})
        self.fam_tree.bind('<<TreeviewSelect>>', lambda _: self.safe(self.refresh_members))
        self.button_row(tab, [('Add family / devotee', self.edit_family),
                              ('Edit family', lambda: self.edit_family(self.selected(self.fam_tree, 'family'))),
                              ('New booking for family', lambda: self.booking(self.selected(self.fam_tree, 'family'))),
                              ('Booking history', self.family_history)])
        ttk.Label(tab, text='Family members — each can have their own seva slip with their rashi and nakshatra').pack(anchor='w')
        self.mem_tree = self.table(tab, ('id', 'name', 'kn', 'relation', 'rashi', 'nakshatra', 'active'),
                                   ('ID', 'Name', 'Kannada', 'Relation', 'Rashi', 'Nakshatra', 'Active'), height=6,
                                   widths={'id': 50, 'active': 60})
        self.button_row(tab, [('Add member', self.edit_member),
                              ('Edit member', lambda: self.edit_member(self.selected(self.mem_tree, 'member')))])

    def refresh_devotees(self):
        families = self.store.families(self.dev_query.get(), MAX_ROWS)
        with self.store.connect() as db:
            counts = dict(db.execute('SELECT family_id, COUNT(*) FROM bookings WHERE family_id IS NOT NULL GROUP BY family_id').fetchall())
        self.fill(self.fam_tree, [(f['id'], (f['id'], f['head'], f['phone'], f['gotra'],
                                             sum(1 for m in f['members'] if m['active']), counts.get(f['id'], 0)))
                                  for f in families])
        self.dev_count.config(text=f'{len(families)} families shown')
        self.refresh_members()

    def refresh_members(self):
        chosen = self.fam_tree.selection()
        members = self.store.family_detail(int(chosen[0]))['members'] if chosen else []
        self.fill(self.mem_tree, [(m['id'], (m['id'], m['name'], m['kannada'], m['relation'], m['rashi'], m['nakshatra'],
                                             'Yes' if m['active'] else 'No')) for m in members])

    def edit_family(self, ident=None):
        f = self.store.family_detail(ident) if ident else {}
        fields = [('head', 'Family / main devotee name', f.get('head', ''), None),
                  ('phone', 'Phone', f.get('phone', ''), None),
                  ('gotra', 'Gotra / ಗೋತ್ರ', f.get('gotra', ''), None),
                  ('address', 'Address / place', f.get('address', ''), None),
                  ('notes', 'Notes', f.get('notes', ''), None)]
        def save(values):
            phone = ''.join(c for c in values['phone'] if c.isdigit())
            if not ident and len(phone) >= 6:
                same = [x for x in self.store.families(phone) if x['id'] != ident]
                if same and not messagebox.askyesno('Possible duplicate', f"Family #{same[0]['id']} ({same[0]['head']}) has this phone number. Create a new family anyway?"):
                    raise ValueError('Not saved. Use the existing family instead.')
            fid = self.store.family(values, ident)
            if not ident:
                self.store.member(dict(family_id=fid, name=values['head'], kannada=suggest(values['head']), relation='Self'))
                self.dev_query.set('')
                self.refresh_devotees()
                self.fam_tree.selection_set(str(fid))
                self.fam_tree.see(str(fid))
                messagebox.showinfo('Devotee saved', 'Family saved with the main devotee as a member. '
                                    'Use Edit member to check the Kannada name and add rashi/nakshatra.')
        self.form('Devotee family', fields, save)

    def edit_member(self, ident=None):
        fid = self.selected(self.fam_tree, 'family')
        m = next((x for x in self.store.family_detail(fid)['members'] if x['id'] == ident), {})
        fields = [('name', 'Name (English)', m.get('name', ''), None),
                  ('kannada', 'Kannada name', m.get('kannada', ''), None),
                  ('relation', 'Relation', m.get('relation', 'Spouse' if not ident else 'Self'), list(RELATIONS)),
                  ('rashi', 'Rashi / ರಾಶಿ', m.get('rashi', ''), [''] + RASHIS),
                  ('nakshatra', 'Nakshatra / ನಕ್ಷತ್ರ', m.get('nakshatra', ''), [''] + NAKSHATRAS),
                  ('active', 'Active', 'Yes' if m.get('active', 1) else 'No', ['Yes', 'No'])]
        def save(values):
            values['family_id'] = fid
            self.store.member(values, ident)
        self.form('Family member', fields, save, kannada=('name', 'kannada', 'name'))

    def family_history(self):
        f = self.store.family_detail(self.selected(self.fam_tree, 'family'))
        win = tk.Toplevel(self.root)
        win.title(f"Booking history — {f['head']}")
        win.geometry('820x420')
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill='both', expand=True)
        tree = self.table(frame, ('id', 'date', 'event', 'devotee', 'total', 'status'),
                          ('Booking', 'Pooja date', 'Event', 'Devotee', 'Total', 'Payment'))
        self.fill(tree, [(b['id'], (b['id'], b['service_date'], json.loads(b['snapshot'])['name'], b['devotee'],
                                    f"{json.loads(b['snapshot'])['currency']} {fmt(b['total'])}", b['status']))
                         for b in f['bookings']])
        def open_receipt():
            self.open_html(receipt(self.store.detail(self.selected(tree, 'booking')), int(self.width.get())), 'devseva-receipt-')
        ttk.Button(frame, text='Preview receipt', command=lambda: self.safe(open_receipt, win)).pack(anchor='e')
        if not f['bookings']:
            ttk.Label(frame, text='No bookings are linked to this family yet. Older bookings made before the register are not linked automatically.').pack(anchor='w')

    # ----------------------------------------------------------------- reports
    def build_reports(self):
        tab = ttk.Frame(self.tabs, padding=6)
        self.tabs.add(tab, text='Reports / ವರದಿ')
        top = ttk.Frame(tab)
        top.pack(fill='x')
        self.rep_from = tk.StringVar(value=today())
        self.rep_to = tk.StringVar(value=today())
        self.rep_event = tk.StringVar(value='All events')
        for label, var in (('From', self.rep_from), ('To', self.rep_to)):
            ttk.Label(top, text=label).pack(side='left', padx=(6, 2))
            ttk.Entry(top, textvariable=var, width=12).pack(side='left')
        ttk.Label(top, text='  Event').pack(side='left')
        self.rep_combo = ttk.Combobox(top, textvariable=self.rep_event, state='readonly', width=34)
        self.rep_combo.pack(side='left', padx=4)
        quick = ttk.Frame(tab)
        quick.pack(fill='x', pady=6)
        def period(kind):
            d = dt.date.today()
            start = {'today': d, 'week': d - dt.timedelta(days=d.weekday()), 'month': d.replace(day=1), 'year': d.replace(month=1, day=1)}[kind]
            self.rep_from.set(start.isoformat())
            self.rep_to.set(d.isoformat())
            self.show_report()
        for title, kind in (('Today', 'today'), ('This week', 'week'), ('This month', 'month'), ('This year', 'year')):
            ttk.Button(quick, text=title, command=lambda k=kind: self.safe(lambda: period(k))).pack(side='left', padx=3)
        for title, command in (('Show report', self.show_report), ('Print report', self.print_report),
                               ('Export slip-level CSV', self.export_report)):
            ttk.Button(quick, text=title, command=lambda c=command: self.safe(c)).pack(side='left', padx=3)
        self.rep_text = tk.Text(tab, wrap='none', font=('Menlo' if sys.platform == 'darwin' else 'Courier', 12))
        self.rep_text.pack(fill='both', expand=True)

    def current_report(self):
        event_id = self.event_choices(active_only=False, include_all=True).get(self.rep_event.get())
        return self.store.report(self.rep_from.get(), self.rep_to.get(), event_id), event_id

    def show_report(self):
        rep, _ = self.current_report()
        self.rep_text.config(state='normal')
        self.rep_text.delete('1.0', 'end')
        self.rep_text.insert('end', f'Event filter: {self.rep_event.get()}\n' + report_text(rep))
        self.rep_text.config(state='disabled')

    def print_report(self):
        rep, _ = self.current_report()
        self.open_html(report_html(rep, f'Collection report — {self.rep_event.get()}'), 'devseva-report-')

    def export_report(self):
        rep, event_id = self.current_report()
        dest = filedialog.asksaveasfilename(defaultextension='.csv', initialfile=f"devseva-slips-{rep['start']}-to-{rep['end']}.csv")
        if dest:
            self.store.export_lines(dest, rep['start'], rep['end'], event_id)
            messagebox.showinfo('Export', 'Slip-level report saved. A slip is included if it was booked, paid or scheduled in the period.')

    # ----------------------------------------------------------------- masters
    def build_masters(self):
        tab = ttk.Frame(self.tabs, padding=6)
        self.tabs.add(tab, text='Masters / ವಿವರಗಳು')
        ttk.Label(tab, text='Events and pooja calendars — "Once" for a festival or event day, "Daily" for regular temple poojas').pack(anchor='w')
        self.events = self.table(tab, ('id', 'name', 'type', 'day', 'end', 'days', 'place', 'currency', 'status'),
                                 ('ID', 'Name', 'Type', 'Date / start', 'End', 'Days', 'Place', 'Cur.', 'Status'), height=6,
                                 widths={'id': 40, 'type': 60, 'currency': 50, 'status': 70, 'name': 240})
        self.button_row(tab, [('Add event / calendar', self.edit_event),
                              ('Edit selected', lambda: self.edit_event(self.selected(self.events, 'event'))),
                              ('Archive / restore', lambda: self.toggle('events', self.events))])
        ttk.Label(tab, text='Sevas, sponsorships and in-kind categories').pack(anchor='w', pady=(8, 0))
        self.sevas = self.table(tab, ('id', 'event', 'name', 'kn', 'kind', 'price', 'limit', 'status'),
                                ('ID', 'Event', 'Seva', 'Kannada', 'Type', 'Default amount', 'Per-day limit', 'Status'), height=8,
                                widths={'id': 40, 'status': 70, 'limit': 90})
        self.button_row(tab, [('Add seva / sponsorship', self.edit_seva),
                              ('Edit selected seva', lambda: self.edit_seva(self.selected(self.sevas, 'seva'))),
                              ('Archive / restore', lambda: self.toggle('sevas', self.sevas))])
        ttk.Label(tab, text='Archived items stay in history and reports but are hidden from new bookings. Existing receipts keep their original details and rates.').pack(anchor='w')

    def refresh_masters(self):
        cat = self.store.catalog()
        names = {e['id']: e['name'] for e in cat['events']}
        self.fill(self.events, [(e['id'], (e['id'], e['name'], e['recurrence'], e['day'], e['end_day'] or '—',
                                           weekday_text(e['weekdays']) if e['recurrence'] == 'Daily' else '—', e['place'],
                                           e['currency'], 'Active' if e['active'] else 'Archived')) for e in cat['events']])
        self.fill(self.sevas, [(s['id'], (s['id'], names.get(s['event_id'], s['event_id']), s['name'], s['kannada'], s['kind'],
                                          fmt(s['price']), s['daily_limit'] or 'No limit', 'Active' if s['active'] else 'Archived'))
                               for s in cat['sevas']])
        choices = list(self.event_choices(active_only=False, include_all=True))
        for combo, var in ((self.sched_combo, self.sched_event), (self.rep_combo, self.rep_event)):
            combo.config(values=choices)
            if var.get() not in choices:
                var.set('All events')

    def toggle(self, table, tree):
        ident = self.selected(tree)
        active = tree.set(str(ident), 'status') == 'Active'
        self.store.set_active(table, ident, not active)
        self.refresh()

    def edit_event(self, ident=None):
        e = next((x for x in self.store.catalog()['events'] if x['id'] == ident), {})
        fields = [('name', 'Event / calendar name', e.get('name', ''), None),
                  ('kannada', 'Kannada name / ಕನ್ನಡ ಹೆಸರು', e.get('kannada', ''), None),
                  ('recurrence', 'Type', e.get('recurrence', 'Once'), list(RECURRENCES)),
                  ('day', 'Date (Once) or start date (Daily) YYYY-MM-DD', e.get('day', today()), None),
                  ('end_day', 'End date (Daily only, optional)', e.get('end_day', ''), None),
                  ('weekdays', 'Days (Daily only): All or e.g. Mon, Fri', weekday_text(e.get('weekdays')), None),
                  ('place', 'Place / ಸ್ಥಳ', e.get('place', ''), None),
                  ('currency', 'Currency', e.get('currency', 'AED'), list(CURRENCIES))]
        self.form('Event / pooja calendar', fields, lambda v: self.store.event(v, ident), kannada=('name', 'kannada', 'label'))

    def edit_seva(self, ident=None):
        cat = self.store.catalog()
        if not cat['events']:
            raise ValueError('Create an event or daily pooja calendar first.')
        options = {f"{e['id']} · {e['name']}": e['id'] for e in cat['events']}
        s = next((x for x in cat['sevas'] if x['id'] == ident), {})
        selected = next((k for k, val in options.items() if val == s.get('event_id')), next(iter(options)))
        fields = [('event_id', 'Event / calendar', selected, list(options)),
                  ('name', 'Seva / contribution name', s.get('name', ''), None),
                  ('kannada', 'Kannada name', s.get('kannada', ''), None),
                  ('kind', 'Type', s.get('kind', 'Seva'), list(KINDS)),
                  ('price', 'Default cash amount', f"{s.get('price', 0) / 100:.2f}", None),
                  ('daily_limit', 'Per-day limit (0 = no limit)', s.get('daily_limit', 0), None)]
        def save(v):
            v['event_id'] = options[v['event_id']]
            self.store.seva(v, ident)
        self.form('Seva master', fields, save, kannada=('name', 'kannada', 'label'))

    # ------------------------------------------------------------------ global
    def refresh(self):
        self.refresh_bookings()
        self.refresh_masters()
        self.safe_schedule()

    def poll(self):
        self.safe(self.refresh)
        self.root.after(4000, self.poll)

    def backup(self):
        dest = filedialog.asksaveasfilename(defaultextension='.sqlite3', initialfile=f'devseva-backup-{today()}.sqlite3')
        if dest:
            if Path(dest).resolve() == (self.folder / 'seva-desk.sqlite3').resolve():
                raise ValueError('Choose a different backup file.')
            self.store.backup(dest)
            messagebox.showinfo('Backup', 'Database backup saved. Copy it to a USB drive or other safe place.')

    def export(self):
        dest = filedialog.asksaveasfilename(defaultextension='.csv', initialfile='devseva-register.csv')
        if dest:
            self.store.export(dest)
            messagebox.showinfo('Export', 'Booking register saved. AED and INR remain separate.')

    def mobile(self):
        if self.server:
            if messagebox.askyesno('Mobile access', 'Stop mobile access and revoke both access keys?'):
                self.server.shutdown()
                self.server.server_close()
                self.server = None
            return
        if not messagebox.askyesno('Enable local mobile entry', 'Connect phones and laptop to a private, password-protected Wi-Fi or hotspot. '
                                   'This prototype uses unencrypted local HTTP. Do not use public/shared Wi-Fi. '
                                   'Reception and cashier phones can search the devotee register (names, gotra, phone). Enable access?'):
            return
        self.server, tokens = start(self.store)
        addresses = set()
        try:
            addresses.update(socket.gethostbyname_ex(socket.gethostname())[2])
        except OSError:
            pass
        win = tk.Toplevel(self.root)
        win.title('Mobile connection details')
        text = tk.Text(win, width=78, height=20, wrap='word')
        text.pack(padx=15, pady=15)
        urls = '\n'.join(f'http://{ip}:8765' for ip in sorted(addresses) if not ip.startswith('127.'))
        text.insert('end', 'Open on phones connected to the same private network:\n' + (urls or 'http://<laptop Wi-Fi IPv4 address>:8765')
                    + '\n\nIf an address does not work, use the laptop Wi-Fi IPv4 shown in network settings. Allow local/private network access through the firewall.\n\n')
        for key, role in tokens.items():
            text.insert('end', f'{role} access key:\n{key}\n\n')
        text.insert('end', 'Reception: register bookings. Cashier: register and receive payments.\n'
                    'Keep this window open to copy the keys. Restarting mobile access changes the keys.\n'
                    'The laptop receives print jobs; open them under Bookings.\n')
        text.configure(state='disabled')

    def close(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()
        for path in self.previews:
            try:
                os.remove(path)
            except OSError:
                pass
        self.root.destroy()


if __name__ == '__main__':
    root = tk.Tk()
    App(root)
    root.mainloop()
