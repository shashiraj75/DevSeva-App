"""DevSeva app icon (a lit diya on maroon), drawn in code so no image files are needed.

Used for the phone "Add to Home Screen" icon on iPhone and Android.
"""
import math
import struct
import zlib
from functools import lru_cache

MAROON = (122, 46, 14)
SAFFRON = (229, 138, 0)
BOWL_DARK = (176, 88, 10)
FLAME_OUT = (255, 170, 30)
FLAME_IN = (255, 236, 150)
GLOW = (255, 196, 90)


def _mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def _colour(x, y, maskable):
    """x, y in 0..1 (y downwards). Returns (r, g, b, a)."""
    # Background: full square for maskable icons (Android crops it), rounded square otherwise.
    if not maskable:
        r = 0.2
        cx, cy = min(max(x, r), 1 - r), min(max(y, r), 1 - r)
        if (x - cx) ** 2 + (y - cy) ** 2 > r * r:
            return (0, 0, 0, 0)
    scale = 0.78 if maskable else 1.0  # keep the drawing inside Android's safe zone
    u = (x - 0.5) / scale + 0.5
    v = (y - 0.5) / scale + 0.5
    colour = _mix(MAROON, (150, 60, 20), max(0.0, 1 - v) * 0.5)
    # soft glow around the flame
    d = math.hypot(u - 0.5, v - 0.40)
    if d < 0.32:
        colour = _mix(colour, GLOW, (1 - d / 0.32) ** 2 * 0.35)
    # bowl: lower half of an ellipse with a flat rim
    bx, by, bw, bh = 0.5, 0.60, 0.30, 0.17
    if v >= by and ((u - bx) / bw) ** 2 + ((v - by) / bh) ** 2 <= 1:
        shade = (u - (bx - bw)) / (2 * bw)
        colour = _mix(SAFFRON, BOWL_DARK, abs(shade - 0.35) * 1.2)
    if abs(v - by) < 0.018 and abs(u - bx) < bw * 1.02:
        colour = (255, 190, 80)
    # foot of the lamp
    if 0.76 <= v <= 0.80 and abs(u - bx) < 0.12:
        colour = BOWL_DARK
    # flame: teardrop (circle at the bottom, tapering to a point on top)
    fx, fy, fr, top = 0.5, 0.47, 0.085, 0.20
    if top <= v <= fy + fr:
        if v >= fy:
            inside = math.hypot(u - fx, v - fy) <= fr
            inner = math.hypot(u - fx, (v - fy) * 1.2) <= fr * 0.55
        else:
            t = (fy - v) / (fy - top)
            half = fr * math.cos(t * math.pi / 2) ** 1.2 * (1 + 0.15 * math.sin(t * math.pi))
            inside = abs(u - fx) <= half
            inner = abs(u - fx) <= half * 0.5 and t < 0.6
        if inside:
            colour = FLAME_IN if inner else FLAME_OUT
    return colour + (255,)


@lru_cache(maxsize=8)
def png(size=180, maskable=False):
    """Anti-aliased PNG bytes of the icon."""
    samples = ((0.25, 0.25), (0.75, 0.25), (0.25, 0.75), (0.75, 0.75))
    rows = []
    for py in range(size):
        row = bytearray(b'\x00')
        for px in range(size):
            acc = [0, 0, 0, 0]
            for sx, sy in samples:
                c = _colour((px + sx) / size, (py + sy) / size, maskable)
                acc[0] += c[0] * c[3]
                acc[1] += c[1] * c[3]
                acc[2] += c[2] * c[3]
                acc[3] += c[3]
            alpha = acc[3] / 4
            if acc[3]:
                row += bytes((int(acc[0] / acc[3]), int(acc[1] / acc[3]), int(acc[2] / acc[3]), int(alpha)))
            else:
                row += b'\x00\x00\x00\x00'
        rows.append(bytes(row))

    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    header = struct.pack('>IIBBBBB', size, size, 8, 6, 0, 0, 0)
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', header) + chunk(b'IDAT', zlib.compress(b''.join(rows), 9))
            + chunk(b'IEND', b''))


def manifest():
    return {
        'name': 'DevSeva — temple counter',
        'short_name': 'DevSeva',
        'description': 'Seva bookings and event-day counter, connected to the DevSeva laptop on this Wi-Fi.',
        'start_url': '/',
        'scope': '/',
        'display': 'standalone',
        'orientation': 'portrait',
        'background_color': '#f6efe4',
        'theme_color': '#7a2e0e',
        'icons': [
            {'src': '/icon-192.png', 'sizes': '192x192', 'type': 'image/png', 'purpose': 'any'},
            {'src': '/icon-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'any'},
            {'src': '/icon-512-maskable.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'maskable'},
        ],
    }
